package com.gugugaga.mediaplatform.data.admin

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import com.gugugaga.mediaplatform.BuildConfig
import com.gugugaga.mediaplatform.data.AppPrefs
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

data class AdminSite(
    val id: String = "",
    val name: String = "",
    val url: String = "",
    val iconUrl: String = "",
    val category: String = "",
    val tags: String = "",
    val description: String = "",
    val active: Boolean = true,
    val featured: Boolean = false,
    val isHot: Boolean = false,
    val priorityScore: Int = 50,
    val isPinned: Boolean = false,
    val hotUntil: Long = 0,
    val rankOrder: Int = 0,
    val adBlockMode: String = "normal",
    val browsingMode: String = "webview",
    val searchUrlPattern: String = "",
    val clickCount: Long = 0,
)

data class AdminCategory(val id: String, val name: String, val order: Int)
data class AdblockCfg(
    val kill: Boolean = false,
    val extra: String = "",
    val allow: String = "",
    val listUrl: String = "",
    val cosmetic: Map<String, String> = emptyMap(),
)
data class AdminReport(val id: String, val type: String, val url: String, val note: String, val ts: Long)
data class AdminLogEntry(val action: String, val target: String, val ts: Long)

/**
 * Admin = one fixed email (BuildConfig.ADMIN_EMAIL); the secret code is the Firebase password.
 * The code is never stored in the app. Real protection = long random code + DB rules (admin UID only)
 * + App Check. The client lockout below is only UX (clear-data bypasses it).
 */
@Singleton
class AdminRepository @Inject constructor(
    private val db: FirebaseDatabase,
    private val prefs: AppPrefs,
) {
    private val auth get() = FirebaseAuth.getInstance()
    @Volatile var lastActivity: Long = 0L

    fun touch() { lastActivity = System.currentTimeMillis() }
    fun isLoggedIn(): Boolean = auth.currentUser != null
    fun logout() { auth.signOut() }
    fun lockRemainingMs(): Long = maxOf(0L, prefs.adminLockUntil - System.currentTimeMillis())
    fun timedOut(): Boolean = isLoggedIn() && System.currentTimeMillis() - lastActivity > SESSION_MS

    suspend fun login(code: String): Result<Unit> {
        val rem = lockRemainingMs()
        if (rem > 0) return Result.failure(IllegalStateException("Locked. ${rem / 1000}s baad try karo."))
        if (code.isBlank()) return Result.failure(IllegalArgumentException("Code daalo"))
        return try {
            auth.signInWithEmailAndPassword(BuildConfig.ADMIN_EMAIL, code.trim()).await()
            prefs.adminFails = 0
            touch()
            Result.success(Unit)
        } catch (e: FirebaseNetworkException) {
            Result.failure(IllegalStateException("Internet check karo"))
        } catch (e: FirebaseTooManyRequestsException) {
            Result.failure(IllegalStateException("Firebase ne temporarily rok diya. Thodi der baad try karo."))
        } catch (e: Exception) {
            registerFail()
            Result.failure(IllegalStateException("Galat code"))
        }
    }

    private fun registerFail() {
        val f = prefs.adminFails + 1
        prefs.adminFails = f
        if (f % 3 == 0) {
            val idx = minOf(f / 3 - 1, LOCKS.size - 1)
            prefs.adminLockUntil = System.currentTimeMillis() + LOCKS[idx]
        }
    }

    private fun ensure() {
        if (!isLoggedIn()) throw IllegalStateException("Login karo")
        if (timedOut()) { logout(); throw IllegalStateException("Session expire (15 min). Dobara login karo.") }
        touch()
    }

    // ------------------------------------------------------------ sites
    suspend fun sites(): List<AdminSite> {
        ensure()
        val s = db.reference.child("websites").get().await()
        return s.children.mapNotNull { c ->
            val id = c.key ?: return@mapNotNull null
            AdminSite(
                id = id, name = c.txt("name"), url = c.txt("url"), iconUrl = c.txt("iconUrl"),
                category = c.txt("category"), tags = c.txt("tags"), description = c.txt("description"),
                active = c.bool("active", true), featured = c.bool("featured", false), isHot = c.bool("isHot", false),
                priorityScore = c.lng("priorityScore").toInt(), isPinned = c.bool("isPinned", false),
                hotUntil = c.lng("hotUntil"), rankOrder = c.lng("rankOrder").toInt(),
                adBlockMode = c.txt("adBlockMode").ifBlank { "normal" },
                browsingMode = c.txt("browsingMode").ifBlank { "webview" },
                searchUrlPattern = c.txt("searchUrlPattern"),
                clickCount = c.lng("clickCount"),
            )
        }.sortedBy { it.name.lowercase() }
    }

    suspend fun saveSite(site: AdminSite) {
        ensure()
        val isNew = site.id.isBlank()
        val id = if (isNew) db.reference.child("websites").push().key!! else site.id
        val b = "websites/$id"
        val m = hashMapOf<String, Any>(
            "$b/name" to site.name.trim().take(80),
            "$b/url" to site.url.trim(),
            "$b/iconUrl" to site.iconUrl.trim(),
            "$b/category" to site.category.trim(),
            "$b/tags" to site.tags.trim().take(200),
            "$b/description" to site.description.trim().take(200),
            "$b/active" to site.active,
            "$b/featured" to site.featured,
            "$b/isHot" to site.isHot,
            "$b/priorityScore" to site.priorityScore.coerceIn(1, 100),
            "$b/isPinned" to site.isPinned,
            "$b/hotUntil" to site.hotUntil,
            "$b/rankOrder" to site.rankOrder,
            "$b/adBlockMode" to site.adBlockMode,
            "$b/browsingMode" to site.browsingMode,
            "$b/searchUrlPattern" to site.searchUrlPattern.trim(),
            "$b/updatedAt" to ServerValue.TIMESTAMP,
            "config/version" to ServerValue.TIMESTAMP,
        )
        if (isNew) {
            m["$b/createdAt"] = ServerValue.TIMESTAMP
            m["$b/clickCount"] = 0 // public +1 rule needs the node to exist
        }
        db.reference.updateChildren(m).await()
        log(if (isNew) "site_add" else "site_edit", site.name)
    }

    suspend fun deleteSite(site: AdminSite) {
        ensure()
        db.reference.child("websites/${site.id}").removeValue().await()
        bumpVersion()
        log("site_delete", site.name)
    }

    // ------------------------------------------------------------ bulk / import / export

    /** action: hot_on|hot_off|active_on|active_off|pin_on|pin_off|category|delete */
    suspend fun bulk(ids: List<String>, action: String, value: String = "") {
        ensure()
        if (ids.isEmpty()) return
        val m = hashMapOf<String, Any?>()
        for (id in ids) {
            when (action) {
                "hot_on" -> m["websites/$id/isHot"] = true
                "hot_off" -> m["websites/$id/isHot"] = false
                "active_on" -> m["websites/$id/active"] = true
                "active_off" -> m["websites/$id/active"] = false
                "pin_on" -> m["websites/$id/isPinned"] = true
                "pin_off" -> m["websites/$id/isPinned"] = false
                "category" -> m["websites/$id/category"] = value.trim()
                "delete" -> m["websites/$id"] = null
            }
            if (action != "delete") m["websites/$id/updatedAt"] = ServerValue.TIMESTAMP
        }
        m["config/version"] = ServerValue.TIMESTAMP
        db.reference.updateChildren(m).await()
        log("bulk_$action", "${ids.size} sites")
    }

    suspend fun setRanks(ranks: Map<String, Int>) {
        ensure()
        val m = hashMapOf<String, Any?>()
        ranks.forEach { (id, r) -> m["websites/$id/rankOrder"] = r }
        m["config/version"] = ServerValue.TIMESTAMP
        db.reference.updateChildren(m).await()
        log("rank_change", "${ranks.size} sites")
    }

    suspend fun exportSites(): String {
        val arr = org.json.JSONArray()
        sites().forEach { s ->
            arr.put(
                org.json.JSONObject().put("name", s.name).put("url", s.url).put("category", s.category)
                    .put("description", s.description).put("tags", s.tags).put("iconUrl", s.iconUrl)
                    .put("priorityScore", s.priorityScore).put("searchUrlPattern", s.searchUrlPattern),
            )
        }
        return arr.toString(2)
    }

    /** JSON array of objects, or CSV lines: name,url,category,description,tags. Returns number imported. */
    suspend fun importSites(text: String): Int {
        ensure()
        val rows = ArrayList<AdminSite>()
        val t = text.trim()
        if (t.startsWith("[")) {
            val a = org.json.JSONArray(t)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                rows.add(
                    AdminSite(
                        name = o.optString("name"), url = o.optString("url"), category = o.optString("category"),
                        description = o.optString("description"), tags = o.optString("tags"), iconUrl = o.optString("iconUrl"),
                        priorityScore = o.optInt("priorityScore", 50), searchUrlPattern = o.optString("searchUrlPattern"),
                    ),
                )
            }
        } else {
            t.lines().forEachIndexed { i, line ->
                val c = line.split(',').map { it.trim() }
                if (c.size < 2 || (i == 0 && c[0].equals("name", true))) return@forEachIndexed
                rows.add(AdminSite(name = c[0], url = c[1], category = c.getOrElse(2) { "" }, description = c.getOrElse(3) { "" }, tags = c.getOrElse(4) { "" }))
            }
        }
        val valid = rows.filter { it.name.isNotBlank() && (it.url.startsWith("http://", true) || it.url.startsWith("https://", true)) }.take(500)
        if (valid.isEmpty()) throw IllegalArgumentException("Koi valid row nahi mili (name + http(s) url chahiye)")
        val m = hashMapOf<String, Any>()
        valid.forEach { s ->
            val id = db.reference.child("websites").push().key!!
            val b = "websites/$id"
            m["$b/name"] = s.name.take(80); m["$b/url"] = s.url; m["$b/category"] = s.category
            m["$b/description"] = s.description.take(200); m["$b/tags"] = s.tags.take(200); m["$b/iconUrl"] = s.iconUrl
            m["$b/active"] = true; m["$b/isHot"] = false; m["$b/isPinned"] = false; m["$b/featured"] = false
            m["$b/priorityScore"] = s.priorityScore.coerceIn(1, 100); m["$b/rankOrder"] = 0; m["$b/hotUntil"] = 0
            m["$b/adBlockMode"] = "normal"; m["$b/browsingMode"] = "webview"; m["$b/searchUrlPattern"] = s.searchUrlPattern
            m["$b/clickCount"] = 0; m["$b/createdAt"] = ServerValue.TIMESTAMP; m["$b/updatedAt"] = ServerValue.TIMESTAMP
        }
        m["config/version"] = ServerValue.TIMESTAMP
        db.reference.updateChildren(m).await()
        log("import", "${valid.size} sites")
        return valid.size
    }

    // ------------------------------------------------------------ categories
    suspend fun categories(): List<AdminCategory> {
        ensure()
        return db.reference.child("categories").get().await().children.mapNotNull { c ->
            val id = c.key ?: return@mapNotNull null
            AdminCategory(id, c.txt("name").ifBlank { id }, c.lng("order").toInt())
        }.sortedBy { it.order }
    }

    suspend fun addCategory(name: String, order: Int) {
        ensure()
        val id = db.reference.child("categories").push().key!!
        db.reference.updateChildren(
            hashMapOf<String, Any>(
                "categories/$id/name" to name.trim().take(40),
                "categories/$id/order" to order,
                "categories/$id/active" to true,
                "config/version" to ServerValue.TIMESTAMP,
            ),
        ).await()
        log("category_add", name)
    }

    suspend fun deleteCategory(c: AdminCategory) {
        ensure()
        db.reference.child("categories/${c.id}").removeValue().await()
        bumpVersion()
        log("category_delete", c.name)
    }

    // ------------------------------------------------------------ ad-block
    suspend fun adblock(): AdblockCfg {
        ensure()
        val s = db.reference.child("adblock").get().await()
        val cos = s.child("cosmeticRules").children.mapNotNull { c -> c.key?.let { it to c.value?.toString().orEmpty() } }.toMap()
        return AdblockCfg(
            kill = s.child("killSwitch").value as? Boolean ?: false,
            extra = s.child("extraBlockedDomains").value?.toString().orEmpty(),
            allow = s.child("allowlist").value?.toString().orEmpty(),
            listUrl = s.child("listUrl").value?.toString().orEmpty(),
            cosmetic = cos,
        )
    }

    suspend fun saveAdblock(cfg: AdblockCfg) {
        ensure()
        if (cfg.listUrl.isNotBlank() && !cfg.listUrl.startsWith("https://")) throw IllegalArgumentException("List URL https:// se shuru hona chahiye")
        db.reference.updateChildren(
            hashMapOf<String, Any>(
                "adblock/killSwitch" to cfg.kill,
                "adblock/extraBlockedDomains" to cfg.extra.trim(),
                "adblock/allowlist" to cfg.allow.trim(),
                "adblock/listUrl" to cfg.listUrl.trim(),
                "adblock/version" to ServerValue.TIMESTAMP,
            ),
        ).await()
        log(if (cfg.kill) "adblock_kill_ON" else "adblock_save", "settings")
    }

    suspend fun saveCosmetic(host: String, selectors: String) {
        ensure()
        val key = host.trim().lowercase().replace('.', '_')
        if (key.isBlank() || key.any { it in "#$[]/" }) throw IllegalArgumentException("Host galat hai")
        db.reference.updateChildren(
            hashMapOf<String, Any>("adblock/cosmeticRules/$key" to selectors.trim(), "adblock/version" to ServerValue.TIMESTAMP),
        ).await()
        log("cosmetic_rule", host)
    }

    suspend fun deleteCosmetic(key: String) {
        ensure()
        db.reference.child("adblock/cosmeticRules/$key").removeValue().await()
        log("cosmetic_delete", key)
    }

    // ------------------------------------------------------------ announcement / reports / log
    suspend fun announcement(): String {
        ensure()
        return db.reference.child("config/announcement").get().await().value?.toString().orEmpty()
    }

    suspend fun saveAnnouncement(text: String) {
        ensure()
        db.reference.updateChildren(
            hashMapOf<String, Any>("config/announcement" to text.trim().take(300), "config/version" to ServerValue.TIMESTAMP),
        ).await()
        log("announcement", text.take(30))
    }

    suspend fun reports(): List<AdminReport> {
        ensure()
        return db.reference.child("reports").orderByKey().limitToLast(100).get().await().children.mapNotNull { c ->
            val id = c.key ?: return@mapNotNull null
            AdminReport(id, c.txt("type"), c.txt("url"), c.txt("note"), c.lng("ts"))
        }.reversed()
    }

    suspend fun deleteReport(id: String) {
        ensure()
        db.reference.child("reports/$id").removeValue().await()
    }

    suspend fun log(): List<AdminLogEntry> {
        ensure()
        return db.reference.child("adminLog").orderByKey().limitToLast(50).get().await().children.map { c ->
            AdminLogEntry(c.txt("action"), c.txt("target"), c.lng("ts"))
        }.reversed()
    }

    // ------------------------------------------------------------ internals
    private suspend fun bumpVersion() {
        db.reference.child("config/version").setValue(ServerValue.TIMESTAMP).await()
    }

    /** Keeps the last 200 entries. */
    private suspend fun log(action: String, target: String) {
        runCatching {
            val ref = db.reference.child("adminLog")
            ref.push().setValue(mapOf("action" to action, "target" to target.take(80), "ts" to ServerValue.TIMESTAMP)).await()
            val keys = ref.orderByKey().get().await().children.mapNotNull { it.key }
            if (keys.size > 200) keys.take(keys.size - 200).forEach { ref.child(it).removeValue() }
        }
    }

    private fun DataSnapshot.txt(k: String): String = child(k).value?.toString().orEmpty()
    private fun DataSnapshot.bool(k: String, d: Boolean): Boolean = (child(k).value as? Boolean) ?: d
    private fun DataSnapshot.lng(k: String): Long = (child(k).value as? Number)?.toLong() ?: 0L

    companion object {
        const val SESSION_MS = 15 * 60_000L
        private val LOCKS = longArrayOf(30_000L, 120_000L, 600_000L, 3_600_000L)
    }
}
