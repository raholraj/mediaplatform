package com.gugugaga.mediaplatform.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.data.local.BookmarkDao
import com.gugugaga.mediaplatform.data.local.BookmarkEntity
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.local.HistoryDao
import com.gugugaga.mediaplatform.data.local.HistoryEntity
import com.gugugaga.mediaplatform.data.local.LearnedDao
import com.gugugaga.mediaplatform.data.local.LearnedPage
import com.gugugaga.mediaplatform.data.local.MyTabDao
import com.gugugaga.mediaplatform.data.local.MyTabEntity
import com.gugugaga.mediaplatform.data.local.SiteDao
import com.gugugaga.mediaplatform.data.local.SiteEntity
import com.gugugaga.mediaplatform.data.remote.SiteRepository
import com.gugugaga.mediaplatform.util.Ranking
import com.gugugaga.mediaplatform.util.Util
import android.net.Uri
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.mapLatest
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class SearchResults(
    val query: String = "",
    val directUrl: String? = null,
    val sites: List<SiteEntity> = emptyList(),
    val siteSearches: List<Pair<SiteEntity, String>> = emptyList(),
    val categories: List<String> = emptyList(),
    val learned: List<LearnedPage> = emptyList(),
    val cart: List<CartItem> = emptyList(),
    val tabs: List<MyTabEntity> = emptyList(),
    val bookmarks: List<BookmarkEntity> = emptyList(),
    val history: List<HistoryEntity> = emptyList(),
) {
    val isEmpty get() = sites.isEmpty() && learned.isEmpty() && cart.isEmpty() && tabs.isEmpty() && bookmarks.isEmpty() && history.isEmpty()
}

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val prefs: AppPrefs,
    private val repo: SiteRepository,
    private val siteDao: SiteDao,
    private val cartDao: CartDao,
    private val tabDao: MyTabDao,
    private val historyDao: HistoryDao,
    private val bookmarkDao: BookmarkDao,
    private val learnedDao: LearnedDao,
) : ViewModel() {

    val query = MutableStateFlow("")
    val catFilter = MutableStateFlow<String?>(null)
    val hotOnly = MutableStateFlow(false)
    val recent = MutableStateFlow(prefs.recentSearches())

    val results: StateFlow<SearchResults> = combine(query.debounce(150), catFilter, hotOnly) { q, c, h -> Triple(q, c, h) }
        .mapLatest { (q, c, h) -> compute(q, c, h) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), SearchResults())

    fun trending(): List<String> = prefs.trending.split(',').map { it.trim() }.filter { it.isNotEmpty() }.take(8)

    fun setQuery(q: String) { query.value = q }
    fun setCategory(c: String?) { catFilter.value = c }
    fun toggleHot() { hotOnly.value = !hotOnly.value }

    fun remember(q: String) {
        prefs.addRecentSearch(q)
        recent.value = prefs.recentSearches()
    }

    fun clearRecent() {
        prefs.clearRecentSearches()
        recent.value = emptyList()
    }

    private suspend fun compute(raw: String, cat: String?, hot: Boolean): SearchResults {
        val q = raw.trim()
        if (q.isEmpty()) return SearchResults()
        val tokens = q.lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
        val now = repo.nowServer()
        val matched = siteDao.getActive()
            .mapNotNull { s ->
                val sc = scoreSite(s, tokens)
                if (sc > 0) s to (sc + Ranking.score(s) * 0.2 + if (Ranking.effectiveHot(s, now)) 15 else 0) else null
            }
            .sortedByDescending { it.second }
            .map { it.first }
        val categories = matched.map { it.category }.filter { it.isNotBlank() }.distinct().take(8)
        val sites = matched
            .filter { cat == null || it.category == cat }
            .filter { !hot || Ranking.effectiveHot(it, now) }
            .take(30)

        // L3: search inside the site itself (admin pattern) or Google site: fallback
        val enc = Uri.encode(q)
        val siteSearches = sites.take(3).map { s ->
            val url = if (s.searchUrlPattern.isNotBlank())
                s.searchUrlPattern.replace("QUERY", enc).replace("{q}", enc)
            else Util.searchUrl("site:${Util.hostOf(s.url)} $q")
            s to url
        }
        return SearchResults(
            query = q,
            directUrl = Util.smartUrl(q),
            sites = sites,
            siteSearches = siteSearches,
            categories = categories,
            learned = if (prefs.learnedIndex) learnedDao.search(q) else emptyList(),
            cart = cartDao.search(q),
            tabs = tabDao.search(q),
            bookmarks = bookmarkDao.search(q),
            history = historyDao.search(q),
        )
    }

    private fun scoreSite(s: SiteEntity, tokens: List<String>): Double {
        val name = s.name.lowercase()
        val tags = s.tags.lowercase()
        val desc = s.description.lowercase()
        val cat = s.category.lowercase()
        var total = 0.0
        for (t in tokens) {
            var sc = 0.0
            if (name.startsWith(t)) sc = 130.0
            else if (name.contains(t)) sc = 100.0
            else if (tags.contains(t)) sc = 60.0
            else if (desc.contains(t)) sc = 30.0
            else if (cat.contains(t)) sc = 25.0
            else if (t.length >= 3) {
                val maxD = if (t.length <= 4) 1 else 2
                val words = name.split(' ', '.', '-', '_').filter { it.isNotEmpty() }
                if (words.any { w -> Util.levenshtein(w, t) <= maxD }) sc = 50.0
            }
            if (sc == 0.0) return 0.0
            total += sc
        }
        return total
    }
}
