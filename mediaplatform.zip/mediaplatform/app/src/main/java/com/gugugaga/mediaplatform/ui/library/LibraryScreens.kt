package com.gugugaga.mediaplatform.ui.library

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gugugaga.mediaplatform.util.Util
import java.text.DateFormat
import java.util.Date

typealias OpenFn = (url: String, title: String, siteId: String) -> Unit

@Composable
private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
}

@Composable
private fun Loading() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
}

@Composable
private fun Empty(msg: String) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(msg, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun LinkRow(title: String, url: String, onClick: () -> Unit, onDelete: () -> Unit, extra: String? = null) {
    ListItem(
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(listOfNotNull(url, extra).joinToString("\n"), maxLines = 2, overflow = TextOverflow.Ellipsis) },
        leadingContent = {
            AsyncImage(model = Util.faviconUrl(url), contentDescription = null, modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)))
        },
        trailingContent = { IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Delete") } },
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
fun CartScreen(onOpen: OpenFn, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.cart.collectAsStateWithLifecycle()
    Column(Modifier.fillMaxSize()) {
        Title("Cart")
        val list = items
        when {
            list == null -> Loading()
            list.isEmpty() -> Empty("Cart khaali hai. Kisi bhi page par menu se 'Add to Cart' karo.")
            else -> LazyColumn {
                items(list, key = { it.id }) { c ->
                    val off = c.offlinePath.isNotBlank()
                    LinkRow(
                        c.title, c.url,
                        { onOpen(if (off) "file://" + c.offlinePath else c.url, c.title, "") },
                        { vm.removeCart(c.id) },
                        if (off) "[Offline]" else null,
                    )
                }
            }
        }
    }
}

@Composable
fun MyTabsScreen(onOpen: OpenFn, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.tabs.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var url by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            Title("My Tabs")
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("Apna koi bhi link daalo (+ button).")
                else -> LazyColumn { items(list, key = { it.id }) { t -> LinkRow(t.name, t.url, { onOpen(t.url, t.name, "") }, { vm.removeTab(t.id) }) } }
            }
        }
        FloatingActionButton(onClick = { dialog = true }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Filled.Add, "Add tab")
        }
    }

    if (dialog) {
        AlertDialog(
            onDismissRequest = { dialog = false },
            title = { Text("Naya tab") },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Naam (optional)") }, singleLine = true)
                    OutlinedTextField(url, { url = it; bad = false }, label = { Text("Link") }, singleLine = true, isError = bad,
                        supportingText = { if (bad) Text("Valid link daalo") })
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (vm.addTab(name, url)) { dialog = false; name = ""; url = "" } else bad = true
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { dialog = false }) { Text("Cancel") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(onOpen: OpenFn, onBack: () -> Unit, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.history.collectAsStateWithLifecycle()
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }
    var confirm by remember { mutableStateOf(false) }
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("History") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            actions = { IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.DeleteSweep, "Clear all") } },
        )
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("History khaali hai.")
                else -> LazyColumn { items(list, key = { it.id }) { h -> LinkRow(h.title, h.url, { onOpen(h.url, h.title, "") }, { vm.removeHistory(h.id) }, fmt.format(Date(h.visitedAt))) } }
            }
        }
    }
    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Poori history delete karein?") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirm = false }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksScreen(onOpen: OpenFn, onBack: () -> Unit, vm: LibraryViewModel = hiltViewModel()) {
    val items by vm.bookmarks.collectAsStateWithLifecycle()
    Scaffold(topBar = {
        TopAppBar(
            title = { Text("Bookmarks") },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
        )
    }) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val list = items
            when {
                list == null -> Loading()
                list.isEmpty() -> Empty("Koi bookmark nahi. Viewer me bookmark icon dabao.")
                else -> LazyColumn { items(list, key = { it.id }) { b -> LinkRow(b.title, b.url, { onOpen(b.url, b.title, "") }, { vm.removeBookmark(b.id) }) } }
            }
        }
    }
}
