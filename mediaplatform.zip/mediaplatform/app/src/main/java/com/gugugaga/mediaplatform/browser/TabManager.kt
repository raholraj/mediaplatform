package com.gugugaga.mediaplatform.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.net.http.SslError
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import com.gugugaga.mediaplatform.data.local.LearnedDao
import com.gugugaga.mediaplatform.data.local.LearnedPage
import org.json.JSONTokener
import java.io.File
import kotlin.math.abs
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.PermissionRequest
import android.webkit.RenderProcessGoneDetail
import android.webkit.SslErrorHandler
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.gugugaga.mediaplatform.adblock.AdBlockEngine
import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.data.local.HistoryDao
import com.gugugaga.mediaplatform.data.local.HistoryEntity
import com.gugugaga.mediaplatform.util.UrlTools
import com.gugugaga.mediaplatform.util.Util
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

class LongPressInfo(val link: String?, val image: String?)

class GeoRequest(val origin: String, val callback: GeolocationPermissions.Callback)

/**
 * Owns all tabs. Max [MAX_LIVE] live WebViews; the rest are suspended (state + thumbnail saved,
 * WebView destroyed) and restored on demand. Single instance so tabs survive navigation.
 * Incognito = no history / no saved session. NOTE: Android WebView has one shared cookie jar,
 * so cookies are NOT isolated for incognito tabs (platform limit).
 */
@Singleton
class TabManager @Inject constructor(
    @ApplicationContext private val app: Context,
    private val prefs: AppPrefs,
    private val adBlock: AdBlockEngine,
    private val historyDao: HistoryDao,
    private val learnedDao: LearnedDao,
) {
    val tabs = mutableStateListOf<Tab>()
    var currentId by mutableLongStateOf(-1L)
    var customView by mutableStateOf<View?>(null)
    var navRequest by mutableIntStateOf(0)
    var nextIncognito by mutableStateOf(false)
    var pendingPermission by mutableStateOf<PermissionRequest?>(null)
    var pendingGeo by mutableStateOf<GeoRequest?>(null)
    var longPress by mutableStateOf<LongPressInfo?>(null)
    var navTarget by mutableStateOf<String?>(null)
    var fileChooser: ((ValueCallback<Array<Uri>>, Intent) -> Unit)? = null

    private var hostContext: Context = app
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var nextId = 1L
    private val customTabDone = HashSet<String>()
    private val upgraded = HashSet<String>()
    private val httpsFailed = HashSet<String>()

    private val mobileUa: String by lazy {
        WebSettings.getDefaultUserAgent(app).replace("; wv", "").replace(Regex(" Version/\\d+\\.\\d+"), "")
    }

    val current: Tab? get() = tabs.firstOrNull { it.id == currentId }

    init { restore() }

    // ------------------------------------------------------------------ tab lifecycle

    fun open(url: String, title: String = "", siteId: String = ""): Tab {
        if (siteId.isNotEmpty() && !nextIncognito) {
            tabs.firstOrNull { it.siteId == siteId && !it.incognito }?.let { select(it.id); return it }
        }
        val incognito = nextIncognito
        nextIncognito = false
        if (tabs.size >= MAX_TABS) tabs.firstOrNull { !it.pinned && it.id != currentId }?.let { closeTab(it.id) }
        val t = Tab(nextId++, url, title.ifBlank { Util.hostOf(url) }, incognito, siteId)
        tabs.add(t)
        select(t.id)
        return t
    }

    fun select(id: Long) {
        val old = current
        if (old != null && old.id != id) captureThumb(old)
        currentId = id
        val t = current ?: return
        t.lastUsed = System.currentTimeMillis()
        ensureLive(t)
        enforceLive()
        persist()
    }

    fun closeTab(id: Long) {
        val idx = tabs.indexOfFirst { it.id == id }
        if (idx < 0) return
        val t = tabs[idx]
        destroy(t)
        tabs.removeAt(idx)
        if (id == currentId) {
            currentId = -1L
            tabs.getOrNull(minOf(idx, tabs.size - 1))?.let { select(it.id) }
        }
        persist()
    }

    fun closeAll() {
        tabs.toList().forEach { destroy(it) }
        tabs.clear()
        currentId = -1L
        persist()
    }

    fun togglePin(t: Tab) { t.pinned = !t.pinned; persist() }

    fun ensureLive(t: Tab) {
        if (t.webView != null) return
        val wv = buildWebView(t)
        t.webView = wv
        t.error = null
        val s = t.savedState
        t.savedState = null
        if (s == null || wv.restoreState(s) == null) wv.loadUrl(t.url)
    }

    /** Memory pressure: suspend every live tab except the current one. */
    fun trim() { tabs.filter { it.id != currentId && it.webView != null }.forEach { suspend(it) } }

    private fun enforceLive() {
        val live = tabs.filter { it.webView != null && it.id != currentId }.sortedByDescending { it.lastUsed }
        live.drop(MAX_LIVE - 1).forEach { suspend(it) }
    }

    private fun suspend(t: Tab) {
        val wv = t.webView ?: return
        captureThumb(t)
        val b = Bundle()
        runCatching { wv.saveState(b) }
        t.savedState = b
        destroyView(wv)
        t.webView = null
    }

    private fun destroy(t: Tab) {
        t.webView?.let { destroyView(it) }
        t.webView = null
        t.savedState = null
    }

    private fun destroyView(wv: WebView) {
        runCatching {
            wv.stopLoading()
            (wv.parent as? ViewGroup)?.removeView(wv)
            wv.destroy()
        }
    }

    /** Called from onRenderProcessGone: the WebView must be destroyed and recreated. */
    private fun dropAfterCrash(t: Tab, msg: String) {
        t.webView?.let { destroyView(it) }
        t.webView = null
        t.savedState = null
        t.error = msg
    }

    fun reload(t: Tab) {
        t.error = null
        val wv = t.webView
        if (wv == null) ensureLive(t) else wv.reload()
    }

    fun captureThumb(t: Tab) {
        val wv = t.webView ?: return
        if (wv.width <= 0 || wv.height <= 0) return
        runCatching {
            val bmp = Bitmap.createBitmap(maxOf(1, wv.width / 4), maxOf(1, wv.height / 4), Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            c.scale(0.25f, 0.25f)
            wv.draw(c)
            t.thumbnail = bmp
        }
    }

    /** Activity context for dialogs / select popups while the browser UI is visible. */
    fun setHost(ctx: Context?) {
        hostContext = ctx ?: app
        tabs.forEach { it.ctxWrapper?.baseContext = hostContext }
    }

    // ------------------------------------------------------------------ per-tab features

    fun setDesktop(t: Tab, on: Boolean) {
        t.desktop = on
        t.webView?.settings?.apply {
            userAgentString = if (on) DESKTOP_UA else mobileUa
            useWideViewPort = true
            loadWithOverviewMode = true
        }
        prefs.setSiteSetting(Util.hostOf(t.url), "desktop", if (on) "1" else null)
        t.webView?.reload()
    }

    fun setTextZoom(t: Tab, z: Int) {
        val v = z.coerceIn(50, 200)
        t.textZoom = v
        t.webView?.settings?.textZoom = v
        prefs.setSiteSetting(Util.hostOf(t.url), "zoom", if (v == 100) null else v.toString())
    }

    fun setForceDark(t: Tab, on: Boolean) {
        t.forceDark = on
        t.webView?.let { applyDark(it.settings, on) }
        prefs.setSiteSetting(Util.hostOf(t.url), "dark", if (on) "1" else null)
    }

    fun setAdMode(t: Tab, mode: String) {
        t.adMode = mode
        prefs.setSiteSetting(Util.hostOf(t.url), "ads", mode)
        t.webView?.reload()
    }

    fun find(t: Tab, q: String) {
        val wv = t.webView ?: return
        if (q.isEmpty()) { wv.clearMatches(); t.findCount = 0; t.findIndex = 0 } else wv.findAllAsync(q)
    }

    fun findNext(t: Tab, forward: Boolean) { t.webView?.findNext(forward) }
    fun clearFind(t: Tab) { t.webView?.clearMatches(); t.findCount = 0; t.findIndex = 0 }

    fun hideCustomView() {
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
    }

    fun launchCustomTab(url: String) {
        runCatching {
            val i = CustomTabsIntent.Builder().build()
            i.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            i.launchUrl(hostContext, Uri.parse(url))
        }
    }

    // ------------------------------------------------------------------ persistence

    private fun persist() {
        runCatching {
            val a = JSONArray()
            tabs.filter { !it.incognito }.forEach {
                a.put(JSONObject().put("url", it.url).put("title", it.title).put("pinned", it.pinned))
            }
            prefs.savedTabs = a.toString()
        }
    }

    private fun restore() {
        runCatching {
            val s = prefs.savedTabs
            if (s.isBlank()) return
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val u = o.optString("url")
                if (!u.startsWith("http")) continue
                tabs.add(Tab(nextId++, u, o.optString("title"), false, "").also { it.pinned = o.optBoolean("pinned") })
            }
        }
    }

    // ------------------------------------------------------------------ extra features

    /** Address bar: URL -> load, otherwise Google search. */
    fun navigate(t: Tab, input: String) {
        val u = Util.smartUrl(input) ?: Util.searchUrl(input.trim())
        val wv = t.webView
        if (wv == null) { t.url = u; ensureLive(t) } else wv.loadUrl(u)
    }

    fun enqueueDownload(url: String, userAgent: String? = null, cd: String? = null, mime: String? = null): Boolean =
        runCatching {
            val req = DownloadManager.Request(Uri.parse(url))
            if (!mime.isNullOrBlank()) req.setMimeType(mime)
            if (!userAgent.isNullOrBlank()) req.addRequestHeader("User-Agent", userAgent)
            CookieManager.getInstance().getCookie(url)?.let { req.addRequestHeader("Cookie", it) }
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, cd, mime))
            val id = (app.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            prefs.addDownloadId(id)
            Toast.makeText(app, "Download shuru", Toast.LENGTH_SHORT).show()
            true
        }.getOrElse {
            Toast.makeText(app, "Ye download supported nahi (blob ya storage permission)", Toast.LENGTH_LONG).show()
            false
        }

    /** MHTML snapshot into app storage; callback gets the file path or null. */
    fun saveOffline(t: Tab, onDone: (String?) -> Unit) {
        val wv = t.webView
        if (wv == null) { onDone(null); return }
        val dir = File(app.filesDir, "offline").apply { mkdirs() }
        val f = File(dir, "p_${abs(t.url.hashCode())}.mht")
        wv.saveWebArchive(f.absolutePath, false) { path -> onDone(path) }
    }

    fun readerMode(t: Tab) { t.webView?.evaluateJavascript(READER_JS, null) }
    fun startPicker(t: Tab) { t.webView?.evaluateJavascript(PICKER_JS, null) }

    fun resetHidden(t: Tab) {
        prefs.setSiteSetting(Util.hostOf(t.url), "hide", null)
        t.webView?.reload()
    }

    /** Learned search index (L2): title + headings + first ~2000 chars, stored only on this phone. */
    private fun learn(view: WebView, url: String) {
        view.evaluateJavascript(LEARN_JS) { res ->
            runCatching {
                val raw = JSONTokener(res).nextValue() as? String ?: return@runCatching
                if (raw.isBlank()) return@runCatching
                val o = JSONObject(raw)
                val page = LearnedPage(url = url, title = o.optString("t"), headings = o.optString("h"), body = o.optString("b"))
                scope.launch { learnedDao.upsert(page); learnedDao.prune() }
            }
        }
    }

    // ------------------------------------------------------------------ WebView construction

    private fun applyDark(s: WebSettings, on: Boolean) {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, on)
        }
    }

    fun permKey(host: String, kind: String) = "$host:$kind"
    fun isAlwaysAllowed(host: String, kinds: List<String>): Boolean =
        kinds.isNotEmpty() && kinds.all { prefs.allowedPerms().contains(permKey(host, it)) }
    fun allowAlways(host: String, kinds: List<String>) { kinds.forEach { prefs.addAllowedPerm(permKey(host, it)) } }

    class AdBridge(private val t: Tab, private val prefs: AppPrefs) {
        @JavascriptInterface
        fun mode(): String = t.adMode

        @JavascriptInterface
        fun rules(): String = prefs.siteSetting(t.pageHost, "hide").orEmpty()

        @JavascriptInterface
        fun save(selector: String) {
            if (selector.isBlank() || selector.length > 200) return
            val h = t.pageHost
            val cur = prefs.siteSetting(h, "hide").orEmpty().split("|||").filter { it.isNotBlank() }
            prefs.setSiteSetting(h, "hide", (cur + selector).distinct().joinToString("|||"))
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildWebView(t: Tab): WebView {
        val cw = MutableContextWrapper(hostContext)
        val wv = WebView(cw)
        t.ctxWrapper = cw
        val host = Util.hostOf(t.url)

        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.setSupportMultipleWindows(true)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false

        s.loadsImagesAutomatically = !prefs.dataSaver
        s.allowFileAccess = t.url.startsWith("file://" + app.filesDir.absolutePath) // only our offline pages
        t.desktop = prefs.siteSetting(host, "desktop") == "1"
        s.userAgentString = if (t.desktop) DESKTOP_UA else mobileUa
        t.textZoom = prefs.siteSetting(host, "zoom")?.toIntOrNull() ?: 100
        s.textZoom = t.textZoom
        t.forceDark = prefs.siteSetting(host, "dark") == "1"
        applyDark(s, t.forceDark)
        t.adMode = adBlock.modeFor(host)
        t.pageHost = host

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(wv, prefs.thirdPartyCookies)
        }

        wv.addJavascriptInterface(AdBridge(t, prefs), "MPAds")
        val docStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)
        if (docStart) {
            runCatching { WebViewCompat.addDocumentStartJavaScript(wv, adBlock.documentStartScript(), setOf("*")) }
        }

        wv.setFindListener { active, count, _ -> t.findIndex = if (count == 0) 0 else active + 1; t.findCount = count }

        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                val mode = t.adMode
                if (mode == "off" || request.isForMainFrame) return null
                if (adBlock.shouldBlock(request.url, t.pageHost, mode)) {
                    t.blockedCounter.incrementAndGet()
                    return adBlock.emptyResponse(request.url)
                }
                return null
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                val scheme = u.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    if (request.isForMainFrame) {
                        val str = u.toString()
                        if (prefs.stripTracking) {
                            val clean = UrlTools.stripTracking(str)
                            if (clean != str) { view.post { view.loadUrl(clean) }; return true }
                        }
                        val h = u.host.orEmpty()
                        if (scheme == "http" && prefs.httpsUpgrade && h !in httpsFailed) {
                            val up = u.buildUpon().scheme("https").build().toString()
                            upgraded.add(up)
                            view.post { view.loadUrl(up) }
                            return true
                        }
                    }
                    return false
                }
                // tel:, mailto:, upi:, intent:... only on a real tap, and only after confirm
                if (request.hasGesture()) pendingExternal = u
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                t.url = url
                t.error = null
                t.progress = 5
                val h = Util.hostOf(url)
                if (h != t.pageHost) {
                    t.pageHost = h
                    t.adMode = adBlock.modeFor(h)
                }
                t.blockedCounter.set(0)
                t.blocked = 0
                if (!docStart && t.adMode != "off") view.evaluateJavascript(adBlock.documentStartScript(), null)
                val cos = adBlock.cosmeticJs(h, t.adMode)
                if (cos.isNotEmpty()) view.evaluateJavascript(cos, null)
            }

            override fun onPageFinished(view: WebView, url: String) {
                t.url = url
                t.progress = 100
                view.title?.takeIf { it.isNotBlank() }?.let { t.title = it }
                t.canBack = view.canGoBack()
                t.canForward = view.canGoForward()
                t.blocked = t.blockedCounter.get()
                val cos = adBlock.cosmeticJs(Util.hostOf(url), t.adMode)
                if (cos.isNotEmpty()) view.evaluateJavascript(cos, null)
                CookieManager.getInstance().flush()
                if (!t.incognito && url.startsWith("http")) {
                    val now = System.currentTimeMillis()
                    if (!(url == t.lastSavedUrl && now - t.lastSavedAt < 5_000)) {
                        t.lastSavedUrl = url; t.lastSavedAt = now
                        prefs.lastUrl = url
                        prefs.lastTitle = t.title
                        scope.launch { historyDao.insert(HistoryEntity(title = t.title.ifBlank { Util.hostOf(url) }, url = url)) }
                    }
                    persist()
                    if (prefs.learnedIndex) learn(view, url)
                }
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                t.url = url
                t.canBack = view.canGoBack()
                t.canForward = view.canGoForward()
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (!request.isForMainFrame) return
                val u = request.url.toString()
                if (upgraded.remove(u)) { // https failed -> fall back to http once, remember host
                    httpsFailed.add(request.url.host.orEmpty())
                    view.post { view.loadUrl(u.replaceFirst("https://", "http://")) }
                    return
                }
                t.error = error.description?.toString() ?: "Page load error"
            }

            override fun onReceivedHttpError(view: WebView, request: WebResourceRequest, errorResponse: WebResourceResponse) {
                if (!request.isForMainFrame || errorResponse.statusCode < 400) return
                val u = request.url
                if (u.host == "accounts.google.com" && errorResponse.statusCode == 403) {
                    t.error = "Google login WebView me block hai. Custom Tab me khola gaya. " +
                        "Dhyan: Custom Tab ki login cookies is tab me share nahi hoti."
                    if (customTabDone.add(u.toString())) launchCustomTab(u.toString()) // once per URL
                    return
                }
                t.error = "HTTP ${errorResponse.statusCode}"
            }

            override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
                handler.cancel() // never auto-proceed on bad certificates
                t.error = "SSL certificate problem"
            }

            override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                dropAfterCrash(t, "Page crash ho gaya (memory kam). Reload karo.")
                return true
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                t.progress = newProgress
                t.blocked = t.blockedCounter.get()
            }

            override fun onReceivedTitle(view: WebView, title: String?) {
                if (!title.isNullOrBlank()) t.title = title
            }

            override fun onShowFileChooser(
                webView: WebView, filePathCallback: ValueCallback<Array<Uri>>, fileChooserParams: FileChooserParams,
            ): Boolean {
                val h = fileChooser
                if (h == null) { filePathCallback.onReceiveValue(null); return true }
                h(filePathCallback, fileChooserParams.createIntent())
                return true
            }

            override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
                if (!isUserGesture) return false // popups without a tap are blocked
                val temp = WebView(MutableContextWrapper(app))
                temp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        val u = r.url.toString()
                        if (u.startsWith("http")) this@TabManager.open(u)
                        v.post { v.destroy() }
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = temp
                resultMsg.sendToTarget()
                return true
            }

            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customViewCallback = callback
            }

            override fun onHideCustomView() { hideCustomView() }

            override fun onPermissionRequest(request: PermissionRequest) { pendingPermission = request }
            override fun onPermissionRequestCanceled(request: PermissionRequest) { if (pendingPermission == request) pendingPermission = null }

            override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                pendingGeo = GeoRequest(origin, callback)
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean =
                runCatching {
                    AlertDialog.Builder(view.context).setMessage(message)
                        .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                        .setOnCancelListener { result.cancel() }.show()
                    true
                }.getOrElse { result.cancel(); true }

            override fun onJsConfirm(view: WebView, url: String, message: String, result: JsResult): Boolean =
                runCatching {
                    AlertDialog.Builder(view.context).setMessage(message)
                        .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                        .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                        .setOnCancelListener { result.cancel() }.show()
                    true
                }.getOrElse { result.cancel(); true }
        }

        wv.setDownloadListener { dlUrl, userAgent, contentDisposition, mime, _ ->
            enqueueDownload(dlUrl, userAgent, contentDisposition, mime)
        }

        wv.setOnLongClickListener { v ->
            val type = (v as WebView).hitTestResult.type
            if (type == WebView.HitTestResult.SRC_ANCHOR_TYPE ||
                type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE ||
                type == WebView.HitTestResult.IMAGE_TYPE
            ) {
                val h = Handler(Looper.getMainLooper()) { m ->
                    val link = m.data.getString("url")?.takeIf { it.startsWith("http") }
                    val img = m.data.getString("src")?.takeIf { it.startsWith("http") }
                    if (link != null || img != null) longPress = LongPressInfo(link, img)
                    true
                }
                v.requestFocusNodeHref(h.obtainMessage())
                true
            } else false
        }
        return wv
    }

    var pendingExternal by mutableStateOf<Uri?>(null)

    companion object {
        private const val LEARN_JS =
            "(function(){try{var h=[];document.querySelectorAll('h1,h2,h3').forEach(function(e,i){if(i<15)h.push((e.innerText||'').trim());});" +
                "var b=((document.body&&document.body.innerText)||'').replace(/\\s+/g,' ').trim().substring(0,2000);" +
                "return JSON.stringify({t:document.title||'',h:h.join(' | '),b:b});}catch(e){return '';}})()"

        private val READER_JS = """
(function(){
 var best=document.querySelector('article')||document.querySelector('main')||null;
 if(!best){ var max=0; document.querySelectorAll('div,section').forEach(function(d){ var s=0; d.querySelectorAll(':scope > p').forEach(function(p){s+=p.innerText.length;}); if(s>max){max=s;best=d;} }); }
 if(!best) return;
 var title=document.title||''; var html='';
 best.querySelectorAll('h1,h2,h3,p,li,blockquote,img,pre').forEach(function(e){
  var tag=e.tagName.toLowerCase();
  if(tag==='img'){ if(e.src && e.naturalWidth>200) html+='<img src="'+e.src+'">'; }
  else { var t=(e.innerText||'').trim(); if(t.length>0) html+='<'+tag+'>'+t.replace(/</g,'&lt;')+'</'+tag+'>'; }
 });
 document.documentElement.innerHTML='<head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{max-width:42em;margin:0 auto;padding:16px;font:18px/1.7 serif;background:#fafafa;color:#222}@media(prefers-color-scheme:dark){body{background:#121212;color:#ddd}}img{max-width:100%;height:auto}</style></head><body><h1>'+title.replace(/</g,'&lt;')+'</h1>'+html+'</body>';
})();
""".trimIndent()

        private val PICKER_JS = """
(function(){
 if(window.__mpPick) return; window.__mpPick=1;
 function sel(e){ if(e.id) return '#'+CSS.escape(e.id); var p=[]; while(e&&e.nodeType===1&&p.length<4){ var s=e.tagName.toLowerCase(); if(e.classList&&e.classList.length){ s+='.'+CSS.escape(e.classList[0]); } p.unshift(s); e=e.parentElement; } return p.join('>'); }
 function h(ev){ ev.preventDefault(); ev.stopPropagation(); var s=sel(ev.target); document.removeEventListener('click',h,true); window.__mpPick=0; try{ MPAds.save(s);}catch(x){} var st=document.createElement('style'); st.textContent=s+'{display:none!important}'; document.documentElement.appendChild(st); }
 document.addEventListener('click',h,true);
})();
""".trimIndent()

        const val MAX_LIVE = 5
        const val MAX_TABS = 30
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }
}
