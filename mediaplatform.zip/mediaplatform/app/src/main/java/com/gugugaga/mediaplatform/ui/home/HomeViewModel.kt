package com.gugugaga.mediaplatform.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.AppPrefs
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.local.CategoryDao
import com.gugugaga.mediaplatform.data.local.CategoryEntity
import com.gugugaga.mediaplatform.data.local.FavoriteDao
import com.gugugaga.mediaplatform.data.local.FavoriteEntity
import com.gugugaga.mediaplatform.data.local.HistoryDao
import com.gugugaga.mediaplatform.data.local.HistoryEntity
import com.gugugaga.mediaplatform.data.local.SiteDao
import com.gugugaga.mediaplatform.data.local.SiteEntity
import com.gugugaga.mediaplatform.data.remote.SiteRepository
import com.gugugaga.mediaplatform.util.Ranking
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUi(
    val categories: List<CategoryEntity> = emptyList(),
    val selected: CategoryEntity? = null,
    val pinned: List<SiteEntity> = emptyList(),
    val hot: List<SiteEntity> = emptyList(),
    val others: List<SiteEntity> = emptyList(),
    val favorites: List<SiteEntity> = emptyList(),
    val favoriteIds: Set<String> = emptySet(),
    val hotIds: Set<String> = emptySet(),
    val newIds: Set<String> = emptySet(),
    val recent: List<HistoryEntity> = emptyList(),
    val totalSites: Int = 0,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repo: SiteRepository,
    private val prefs: AppPrefs,
    siteDao: SiteDao,
    categoryDao: CategoryDao,
    private val favDao: FavoriteDao,
    private val cartDao: CartDao,
    private val historyDao: HistoryDao,
) : ViewModel() {

    private val selected = MutableStateFlow<CategoryEntity?>(null)
    val syncing = MutableStateFlow(false)
    val syncError = MutableStateFlow<String?>(null)

    val ui: StateFlow<HomeUi> = combine(
        siteDao.observeActive(),
        categoryDao.observeActive(),
        favDao.observeIds(),
        historyDao.observeRecent(10),
        selected,
    ) { sites, cats, favIds, recent, sel ->
        val now = repo.nowServer()
        val categories = cats.ifEmpty {
            sites.map { it.category }.filter { it.isNotBlank() }.distinct().map { CategoryEntity(it, it) }
        }
        val filtered = if (sel == null) sites else sites.filter { it.category == sel.id || it.category.equals(sel.name, true) }
        val sorted = Ranking.sorted(filtered, now)
        val pinned = sorted.filter { it.isPinned }
        val hot = sorted.filter { !it.isPinned && Ranking.effectiveHot(it, now) }
        val used = (pinned + hot).map { it.id }.toSet()
        HomeUi(
            categories = categories,
            selected = sel,
            pinned = pinned,
            hot = hot,
            others = sorted.filter { it.id !in used },
            favorites = sites.filter { it.id in favIds },
            favoriteIds = favIds.toSet(),
            hotIds = hot.map { it.id }.toSet(),
            newIds = sites.filter { it.createdAt > 0 && now - it.createdAt < 7 * 86_400_000L }.map { it.id }.toSet(),
            recent = recent,
            totalSites = sites.size,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeUi())

    init {
        viewModelScope.launch {
            val days = prefs.historyAutoClearDays
            if (days > 0) historyDao.deleteOlderThan(System.currentTimeMillis() - days * 86_400_000L)
        }
        refresh(false)
    }

    fun refresh(force: Boolean) {
        if (syncing.value) return
        viewModelScope.launch {
            syncing.value = true
            syncError.value = null
            repo.sync(force).onFailure { syncError.value = "Sync nahi ho paya (internet check karo). Purana data dikh raha hai." }
            syncing.value = false
        }
    }

    fun selectCategory(c: CategoryEntity?) { selected.value = c }

    fun onOpen(site: SiteEntity) { repo.recordOpen(site.id) }

    fun toggleFavorite(id: String, isFav: Boolean) {
        viewModelScope.launch { if (isFav) favDao.delete(id) else favDao.insert(FavoriteEntity(id)) }
    }

    fun addToCart(site: SiteEntity) {
        viewModelScope.launch { cartDao.insert(CartItem(title = site.name, url = site.url)) }
    }

    fun announcement(): String = prefs.announcement

    fun lastOpened(): Pair<String, String>? =
        prefs.lastUrl.takeIf { it.isNotBlank() }?.let { it to prefs.lastTitle }
}
