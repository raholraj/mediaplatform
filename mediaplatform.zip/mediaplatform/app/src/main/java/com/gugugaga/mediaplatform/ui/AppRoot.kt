package com.gugugaga.mediaplatform.ui

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.gugugaga.mediaplatform.R
import com.gugugaga.mediaplatform.ui.admin.AdminScreen
import com.gugugaga.mediaplatform.ui.browser.BrowserScreen
import com.gugugaga.mediaplatform.ui.browser.TabSwitcherScreen
import com.gugugaga.mediaplatform.ui.browser.TabsViewModel
import com.gugugaga.mediaplatform.ui.extras.DownloadsScreen
import com.gugugaga.mediaplatform.ui.extras.OnboardingScreen
import com.gugugaga.mediaplatform.ui.extras.PrivacyScreen
import com.gugugaga.mediaplatform.ui.extras.SitePermissionsScreen
import com.gugugaga.mediaplatform.ui.home.HomeScreen
import com.gugugaga.mediaplatform.ui.library.BookmarksScreen
import com.gugugaga.mediaplatform.ui.library.CartScreen
import com.gugugaga.mediaplatform.ui.library.HistoryScreen
import com.gugugaga.mediaplatform.ui.library.MyTabsScreen
import com.gugugaga.mediaplatform.ui.search.SearchScreen
import com.gugugaga.mediaplatform.ui.settings.SettingsScreen

enum class Dest(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    Home("home", R.string.nav_home, Icons.Filled.Home),
    Search("search", R.string.nav_search, Icons.Filled.Search),
    Cart("cart", R.string.nav_cart, Icons.Filled.ShoppingCart),
    MyTabs("mytabs", R.string.nav_tabs, Icons.Filled.Tab),
    Settings("settings", R.string.nav_settings, Icons.Filled.Settings),
}

private fun NavHostController.goTop(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

private fun NavHostController.goBrowser() {
    navigate("browser") {
        popUpTo("browser") { inclusive = true }
        launchSingleTop = true
    }
}

@Composable
fun AppRoot(tabsVm: TabsViewModel = hiltViewModel()) {
    val manager = tabsVm.manager
    val prefs = tabsVm.prefs
    var onboarded by remember { mutableStateOf(prefs.onboarded) }
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val showBar = Dest.entries.any { it.route == current }

    val open: (String, String, String) -> Unit = { u, t, id -> manager.open(u, t, id); nav.goBrowser() }

    // Intents from outside (share target / open-with / pinned shortcut)
    LaunchedEffect(manager.navRequest) { if (manager.navRequest > 0) nav.goBrowser() }
    LaunchedEffect(manager.navTarget) {
        manager.navTarget?.let { nav.goTop(it); manager.navTarget = null }
    }

    if (!onboarded) {
        OnboardingScreen(onDone = { prefs.onboarded = true; onboarded = true })
        return
    }

    Scaffold(
        bottomBar = {
            if (showBar) {
                NavigationBar {
                    Dest.entries.forEach { d ->
                        NavigationBarItem(
                            selected = current == d.route,
                            onClick = { nav.goTop(d.route) },
                            icon = { Icon(d.icon, contentDescription = null) },
                            label = { Text(stringResource(d.label)) },
                        )
                    }
                }
            }
        },
    ) { pad ->
        NavHost(
            nav,
            startDestination = Dest.Home.route,
            modifier = Modifier.padding(if (showBar) pad else PaddingValues(0.dp)),
        ) {
            composable(Dest.Home.route) {
                HomeScreen(
                    onOpen = open,
                    onSearch = { nav.goTop(Dest.Search.route) },
                    tabCount = manager.tabs.size,
                    onTabs = { nav.navigate("tabs") { launchSingleTop = true } },
                )
            }
            composable(Dest.Search.route) { SearchScreen(onOpen = open) }
            composable(Dest.Cart.route) { CartScreen(onOpen = open) }
            composable(Dest.MyTabs.route) { MyTabsScreen(onOpen = open) }
            composable(Dest.Settings.route) {
                SettingsScreen(
                    onHistory = { nav.navigate("history") },
                    onBookmarks = { nav.navigate("bookmarks") },
                    onDownloads = { nav.navigate("downloads") },
                    onPermissions = { nav.navigate("permissions") },
                    onPrivacy = { nav.navigate("privacy") },
                    onAdmin = { nav.navigate("admin") { launchSingleTop = true } },
                )
            }
            composable("history") { HistoryScreen(onOpen = open, onBack = { nav.popBackStack() }) }
            composable("bookmarks") { BookmarksScreen(onOpen = open, onBack = { nav.popBackStack() }) }
            composable("browser") {
                BrowserScreen(
                    manager = manager,
                    onClose = { nav.popBackStack() },
                    onTabs = { nav.navigate("tabs") { launchSingleTop = true } },
                    onNewTab = { nav.goTop(Dest.Search.route) },
                )
            }
            composable("tabs") {
                TabSwitcherScreen(
                    manager = manager,
                    onBack = { nav.popBackStack() },
                    onOpenTab = { id -> manager.select(id); nav.goBrowser() },
                    onNewTab = { nav.goTop(Dest.Search.route) },
                    onNewIncognito = { manager.nextIncognito = true; nav.goTop(Dest.Search.route) },
                )
            }
            composable("downloads") { DownloadsScreen(prefs = prefs, onBack = { nav.popBackStack() }) }
            composable("permissions") { SitePermissionsScreen(prefs = prefs, onBack = { nav.popBackStack() }) }
            composable("privacy") { PrivacyScreen(onBack = { nav.popBackStack() }) }
            composable("admin") { AdminScreen(onExit = { nav.popBackStack() }) }
        }
    }
}
