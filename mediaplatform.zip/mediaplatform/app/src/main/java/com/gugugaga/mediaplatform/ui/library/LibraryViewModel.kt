package com.gugugaga.mediaplatform.ui.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.local.BookmarkDao
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.HistoryDao
import com.gugugaga.mediaplatform.data.local.MyTabDao
import com.gugugaga.mediaplatform.data.local.MyTabEntity
import com.gugugaga.mediaplatform.util.Util
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val cartDao: CartDao,
    private val tabDao: MyTabDao,
    private val historyDao: HistoryDao,
    private val bookmarkDao: BookmarkDao,
) : ViewModel() {
    private val keep = SharingStarted.WhileSubscribed(5_000)
    val cart = cartDao.observe().stateIn(viewModelScope, keep, null)
    val tabs = tabDao.observe().stateIn(viewModelScope, keep, null)
    val history = historyDao.observeAll().stateIn(viewModelScope, keep, null)
    val bookmarks = bookmarkDao.observe().stateIn(viewModelScope, keep, null)

    fun removeCart(id: Long) { viewModelScope.launch { cartDao.delete(id) } }
    fun removeTab(id: Long) { viewModelScope.launch { tabDao.delete(id) } }
    fun removeHistory(id: Long) { viewModelScope.launch { historyDao.delete(id) } }
    fun clearHistory() { viewModelScope.launch { historyDao.clear() } }
    fun removeBookmark(id: Long) { viewModelScope.launch { bookmarkDao.delete(id) } }

    /** Returns false if the URL is not valid. */
    fun addTab(name: String, rawUrl: String): Boolean {
        val url = Util.smartUrl(rawUrl) ?: return false
        viewModelScope.launch { tabDao.insert(MyTabEntity(name = name.ifBlank { Util.hostOf(url) }, url = url)) }
        return true
    }
}
