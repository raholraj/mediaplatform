package com.gugugaga.mediaplatform.ui.browser

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.ViewGroup
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import com.gugugaga.mediaplatform.MainActivity
import com.gugugaga.mediaplatform.R
import com.gugugaga.mediaplatform.browser.Tab
import com.gugugaga.mediaplatform.browser.TabManager
import com.gugugaga.mediaplatform.ui.viewer.ViewerViewModel
import com.gugugaga.mediaplatform.util.Util

@Composable
fun BrowserScreen(
    manager: TabManager,
    onClose: () -> Unit,
    onTabs: () -> Unit,
    onNewTab: () -> Unit,
    vm: ViewerViewModel = hiltViewModel(),
) {
    val context = LocalContext.current
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val chooser = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        val req = manager.pendingPermission
        if (req != null) {
            val granted = req.resources.filter { r ->
                when (r) {
                    PermissionRequest.RESOURCE_VIDEO_CAPTURE -> res[Manifest.permission.CAMERA] == true
                    PermissionRequest.RESOURCE_AUDIO_CAPTURE -> res[Manifest.permission.RECORD_AUDIO] == true
                    else -> false
                }
            }
            if (granted.isEmpty()) req.deny() else req.grant(granted.toTypedArray())
            manager.pendingPermission = null
        }
    }
    val geoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        manager.pendingGeo?.let { g -> g.callback.invoke(g.origin, res.values.any { it }, false) }
        manager.pendingGeo = null
    }

    DisposableEffect(Unit) {
        manager.setHost(context)
        manager.fileChooser = { cb, intent ->
            fileCallback?.onReceiveValue(null)
            fileCallback = cb
            runCatching { chooser.launch(intent) }.onFailure { cb.onReceiveValue(null); fileCallback = null }
        }
        onDispose {
            manager.setHost(null)
            manager.fileChooser = null
        }
    }

    val tab = manager.current
    if (tab == null) {
        LaunchedEffect(Unit) { onClose() }
    } else {
        BrowserContent(manager, tab, onClose, onTabs, onNewTab, vm)
    }

    LaunchedEffect(manager.pendingPermission) {
        val req = manager.pendingPermission ?: return@LaunchedEffect
        if (manager.isAlwaysAllowed(req.origin.host.orEmpty(), kindsOf(req))) {
            val needed = neededPerms(req)
            if (needed.isEmpty()) { req.deny(); manager.pendingPermission = null } else permLauncher.launch(needed)
        }
    }

    manager.pendingPermission?.let { req ->
        val host = req.origin.host.orEmpty()
        val kinds = kindsOf(req)
        if (!manager.isAlwaysAllowed(host, kinds)) {
            AlertDialog(
                onDismissRequest = { req.deny(); manager.pendingPermission = null },
                title = { Text("Permission chahiye") },
                text = { Text("$host ko ${kinds.joinToString(" + ")} use karne dein?") },
                confirmButton = {
                    Row {
                        TextButton(onClick = {
                            manager.allowAlways(host, kinds)
                            val needed = neededPerms(req)
                            if (needed.isEmpty()) { req.deny(); manager.pendingPermission = null } else permLauncher.launch(needed)
                        }) { Text("Hamesha") }
                        TextButton(onClick = {
                            val needed = neededPerms(req)
                            if (needed.isEmpty()) { req.deny(); manager.pendingPermission = null } else permLauncher.launch(needed)
                        }) { Text("Allow") }
                    }
                },
                dismissButton = { TextButton(onClick = { req.deny(); manager.pendingPermission = null }) { Text("Deny") } },
            )
        }
    }

    manager.pendingGeo?.let { g -> g.callback.invoke(g.origin, res.values.any { it }, false) }
        manager.pendingGeo = null
    }

    DisposableEffect(Unit) {
        manager.setHost(context)
        manager.fileChooser = { cb, intent ->
            fileCallback?.onReceiveValue(null)
            fileCallback = cb
            runCatching { chooser.launch(intent) }.onFailure { cb.onReceiveValue(null); fileCallback = null }
        }
        onDispose {
            manager.setHost(null)
            manager.fileChooser = null
        }
    }

    val tab = manager.current
    if (tab == null) {
        LaunchedEffect(Unit) { onClose() }
    } else {
        BrowserContent(manager, tab, onClose, onTabs, onNewTab, vm)
    }

    manager.pendingPermission?.let { req ->
        val what = req.resources.mapNotNull {
            when (it) {
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
                else -> null
            }
        }.joinToString(" + ")
        AlertDialog(
            onDismissRequest = { req.deny(); manager.pendingPermission = null },
            title = { Text("Permission chahiye") },
            text = { Text("${req.origin.host} ko $what use karne dein?") },
            confirmButton = {
                TextButton(onClick = {
                    val needed = req.resources.mapNotNull {
                        when (it) {
                            PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
                            PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
                            else -> null
                        }
                    }
                    if (needed.isEmpty()) { req.deny(); manager.pendingPermission = null }
                    else permLauncher.launch(needed.toTypedArray())
                }) { Text("Allow") }
            },
            dismissButton = { TextButton(onClick = { req.deny(); manager.pendingPermission = null }) { Text("Deny") } },
        )
    }

    manager.pendingGeo?.let { g ->
        AlertDialog(
            onDismissRequest = { g.callback.invoke(g.origin, false, false); manager.pendingGeo = null },
            title = { Text("Location permission") },
            text = { Text("${Uri.parse(g.origin).host ?: g.origin} aapki location maang raha hai.") },
            confirmButton = {
                TextButton(onClick = {
                    geoLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                }) { Text("Allow") }
            },
            dismissButton = { TextButton(onClick = { g.callback.invoke(g.origin, false, false); manager.pendingGeo = null }) { Text("Deny") } },
        )
    }

    manager.pendingExternal?.let { u ->
        AlertDialog(
            onDismissRequest = { manager.pendingExternal = null },
            title = { Text("Dusri app kholein?") },
            text = { Text(u.toString().take(200)) },
            confirmButton = {
                TextButton(onClick = {
                    manager.pendingExternal = null
                    runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        .onFailure { Toast.makeText(context, "Koi app nahi mili", Toast.LENGTH_SHORT).show() }
                }) { Text("Open") }
            },
            dismissButton = { TextButton(onClick = { manager.pendingExternal = null }) { Text("Cancel") } },
        )
    }
    manager.longPress?.let { lp ->
        AlertDialog(
            onDismissRequest = { manager.longPress = null },
            title = { Text((lp.link ?: lp.image).orEmpty().take(80)) },
            text = {
                Column {
                    lp.link?.let { l ->
                        TextButton(onClick = { manager.longPress = null; manager.open(l) }) { Text("Naye tab me kholo") }
                        TextButton(onClick = {
                            manager.longPress = null
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("url", l))
                            Toast.makeText(context, "Link copy ho gaya", Toast.LENGTH_SHORT).show()
                        }) { Text("Link copy") }
                        TextButton(onClick = { manager.longPress = null; Util.share(context, l) }) { Text("Link share") }
                        TextButton(onClick = {
                            manager.longPress = null
                            vm.addToCart(Util.hostOf(l), l)
                            Toast.makeText(context, "Cart me add hua", Toast.LENGTH_SHORT).show()
                        }) { Text("Cart me add") }
                    }
                    lp.image?.let { im ->
                        TextButton(onClick = { manager.longPress = null; manager.enqueueDownload(im) }) { Text("Image save") }
                        TextButton(onClick = { manager.longPress = null; manager.open(im) }) { Text("Image tab me kholo") }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { manager.longPress = null }) { Text("Close") } },
        )
    }
}

private fun kindsOf(req: PermissionRequest): List<String> = req.resources.mapNotNull {
    when (it) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> "camera"
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> "microphone"
        else -> null
    }
}

private fun neededPerms(req: PermissionRequest): Array<String> = req.resources.mapNotNull {
    when (it) {
        PermissionRequest.RESOURCE_VIDEO_CAPTURE -> Manifest.permission.CAMERA
        PermissionRequest.RESOURCE_AUDIO_CAPTURE -> Manifest.permission.RECORD_AUDIO
        else -> null
    }
}.toTypedArray()


@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun BrowserContent(
    manager: TabManager,
    tab: Tab,
    onClose: () -> Unit,
    onTabs: () -> Unit,
    onNewTab: () -> Unit,
    vm: ViewerViewModel,
) {
    val context = LocalContext.current
    var menuOpen by remember { mutableStateOf(false) }
    var finding by remember { mutableStateOf(false) }
    var findQuery by remember { mutableStateOf("") }
    var reportDialog by remember { mutableStateOf(false) }
    var reportNote by remember { mutableStateOf("") }
    var editingUrl by remember { mutableStateOf(false) }
    var urlInput by remember { mutableStateOf("") }

    val bookmarked by remember(tab.url) { vm.isBookmarked(tab.url) }.collectAsState(initial = false)
    val shownTitle = tab.title.ifBlank { Util.hostOf(tab.url) }
    val wv = tab.webView
    val cv = manager.customView

    LaunchedEffect(cv) {
        val w = (context as? Activity)?.window ?: return@LaunchedEffect
        val c = WindowCompat.getInsetsController(w, w.decorView)
        if (cv != null) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    BackHandler {
        when {
            finding -> { finding = false; findQuery = ""; manager.clearFind(tab) }
            wv != null && wv.canGoBack() -> wv.goBack()
            else -> onClose()
        }
    }

    if (cv != null) {
        BackHandler { manager.hideCustomView() }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { (cv.parent as? ViewGroup)?.removeView(cv); cv },
                modifier = Modifier.fillMaxSize(),
            )
        }
        return
    }

    Scaffold(
        topBar = {
            Column {
                if (editingUrl) {
                    TopAppBar(
                        title = {
                            OutlinedTextField(
                                value = urlInput,
                                onValueChange = { urlInput = it },
                                singleLine = true,
                                placeholder = { Text("URL ya search") },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                                keyboardActions = KeyboardActions(onGo = {
                                    if (urlInput.isNotBlank()) manager.navigate(tab, urlInput)
                                    editingUrl = false
                                }),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        },
                        navigationIcon = { IconButton(onClick = { editingUrl = false }) { Icon(Icons.Filled.Close, "Cancel") } },
                    )
                } else if (finding) {
                    TopAppBar(
                        title = {
                            OutlinedTextField(
                                value = findQuery,
                                onValueChange = { findQuery = it; manager.find(tab, it) },
                                singleLine = true,
                                placeholder = { Text("Page me dhundo") },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = { finding = false; findQuery = ""; manager.clearFind(tab) }) { Icon(Icons.Filled.Close, "Close find") }
                        },
                        actions = {
                            Text(if (tab.findCount == 0) "0" else "${tab.findIndex}/${tab.findCount}", style = MaterialTheme.typography.labelMedium)
                            IconButton(onClick = { manager.findNext(tab, false) }) { Icon(Icons.Filled.KeyboardArrowUp, "Previous") }
                            IconButton(onClick = { manager.findNext(tab, true) }) { Icon(Icons.Filled.KeyboardArrowDown, "Next") }
                        },
                    )
                } else {
                    TopAppBar(
                        title = {
                            Column(Modifier.clickable { urlInput = tab.url; editingUrl = true }) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (tab.url.startsWith("https")) Icons.Filled.Lock else Icons.Filled.LockOpen,
                                        contentDescription = null, modifier = Modifier.size(14.dp),
                                    )
                                    Text(
                                        (if (tab.incognito) " [Incognito] " else " ") + shownTitle,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall,
                                    )
                                }
                                Text(tab.url, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall)
                            }
                        },
                        navigationIcon = { IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back to app") } },
                        actions = {
                            TextButton(onClick = { manager.captureThumb(tab); onTabs() }) { Text("${manager.tabs.size}") }
                            if (tab.progress in 1..99) {
                                IconButton(onClick = { wv?.stopLoading() }) { Icon(Icons.Filled.Close, "Stop") }
                            } else {
                                IconButton(onClick = { manager.reload(tab) }) { Icon(Icons.Filled.Refresh, "Refresh") }
                            }
                            IconButton(onClick = { vm.toggleBookmark(shownTitle, tab.url, bookmarked) }) {
                                Icon(if (bookmarked) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder, "Bookmark")
                            }
                            Box {
                                IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, "More") }
                                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                    MenuItem("New tab") { menuOpen = false; onNewTab() }
                                    MenuItem("Add to Cart") {
                                        menuOpen = false
                                        vm.addToCart(shownTitle, tab.url)
                                        Toast.makeText(context, "Cart me add hua", Toast.LENGTH_SHORT).show()
                                    }
                                    MenuItem("Find in page") { menuOpen = false; finding = true }
                                    MenuItem("Reader mode") { menuOpen = false; manager.readerMode(tab) }
                                    MenuItem("Save page offline") {
                                        menuOpen = false
                                        manager.saveOffline(tab) { p ->
                                            if (p != null) {
                                                vm.addOfflineCart(shownTitle, tab.url, p)
                                                Toast.makeText(context, "Offline save hua (Cart me, Offline badge)", Toast.LENGTH_SHORT).show()
                                            } else Toast.makeText(context, "Offline save nahi ho paya", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    MenuItem("Element hatao (tap karke)") {
                                        menuOpen = false
                                        manager.startPicker(tab)
                                        Toast.makeText(context, "Jo hatana hai us par tap karo", Toast.LENGTH_LONG).show()
                                    }
                                    MenuItem("Hatae hue elements reset") { menuOpen = false; manager.resetHidden(tab) }
                                    MenuItem((if (tab.desktop) "✓ " else "") + "Desktop site") { menuOpen = false; manager.setDesktop(tab, !tab.desktop) }
                                    MenuItem((if (tab.forceDark) "✓ " else "") + "Dark pages (dark theme me)") { menuOpen = false; manager.setForceDark(tab, !tab.forceDark) }
                                    MenuItem("Text bada (${tab.textZoom}%)") { manager.setTextZoom(tab, tab.textZoom + 10) }
                                    MenuItem("Text chhota (${tab.textZoom}%)") { manager.setTextZoom(tab, tab.textZoom - 10) }
                                    MenuItem("Ad-block: ${tab.adMode} · ${tab.blocked} blocked (badlo)") {
                                        menuOpen = false
                                        manager.setAdMode(tab, when (tab.adMode) { "normal" -> "strict"; "strict" -> "off"; else -> "normal" })
                                    }
                                    MenuItem("Share") { menuOpen = false; Util.share(context, "$shownTitle\n${tab.url}") }
                                    MenuItem("Copy link") {
                                        menuOpen = false
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        cm.setPrimaryClip(ClipData.newPlainText("url", tab.url))
                                        Toast.makeText(context, "Link copy ho gaya", Toast.LENGTH_SHORT).show()
                                    }
                                    MenuItem("Dusri app me kholo") {
                                        menuOpen = false
                                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(tab.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                                    }
                                    MenuItem("Custom Tab me kholo") { menuOpen = false; manager.launchCustomTab(tab.url) }
                                    MenuItem("Add to Home screen") { menuOpen = false; pinShortcut(context, shownTitle, tab.url) }
                                    MenuItem("Report this site") { menuOpen = false; reportDialog = true }
                                    MenuItem("Close tab") { menuOpen = false; manager.closeTab(tab.id) }
                                }
                            }
                        },
                    )
                }
                if (tab.progress in 1..99) LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth())
            }
        },
        bottomBar = {
            BottomAppBar {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton(onClick = { wv?.goBack() }, enabled = tab.canBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                    IconButton(onClick = { wv?.goForward() }, enabled = tab.canForward) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward") }
                }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (wv != null) {
                key(wv) {
                    DisposableEffect(wv) {
                        wv.onResume()
                        onDispose { wv.onPause() }
                    }
                    AndroidView(
                        factory = { (wv.parent as? ViewGroup)?.removeView(wv); wv },
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            }
            tab.error?.let { msg ->
                Column(
                    Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface).padding(24.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Page load nahi hua", style = MaterialTheme.typography.titleMedium)
                    Text(msg, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 8.dp))
                    Button(onClick = { manager.reload(tab) }) { Text("Retry") }
                    OutlinedButton(onClick = { manager.launchCustomTab(tab.url) }, modifier = Modifier.padding(top = 8.dp)) { Text("Custom Tab me kholo") }
                }
            }
        }
    }

    if (reportDialog) {
        AlertDialog(
            onDismissRequest = { reportDialog = false },
            title = { Text("Site report karo") },
            text = {
                OutlinedTextField(reportNote, { reportNote = it.take(280) }, label = { Text("Kya problem hai? (toot gayi / abuse)") })
            },
            confirmButton = {
                TextButton(onClick = {
                    reportDialog = false
                    vm.report("breakage", tab.url, reportNote) { ok ->
                        Toast.makeText(context, if (ok) "Report bhej di" else "Report nahi gayi", Toast.LENGTH_SHORT).show()
                    }
                    reportNote = ""
                }) { Text("Bhejo") }
            },
            dismissButton = { TextButton(onClick = { reportDialog = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun MenuItem(text: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(text) }, onClick = onClick)
}

private fun pinShortcut(ctx: Context, title: String, url: String) {
    runCatching {
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
            Toast.makeText(ctx, "Ye launcher shortcut support nahi karta", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url), ctx, MainActivity::class.java)
        val info = ShortcutInfoCompat.Builder(ctx, "site_" + url.hashCode())
            .setShortLabel(title.take(20).ifBlank { "Site" })
            .setIcon(IconCompat.createWithResource(ctx, R.drawable.ic_launcher))
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
    }.onFailure { Toast.makeText(ctx, "Shortcut nahi ban paya", Toast.LENGTH_SHORT).show() }
}
