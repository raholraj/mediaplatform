package com.gugugaga.mediaplatform.data.remote

import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ServerValue
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

/** Public, create-only reports (breakage / abuse). Admin reads them in the panel. */
@Singleton
class ReportRepository @Inject constructor(private val db: FirebaseDatabase) {
    suspend fun report(type: String, url: String, note: String): Result<Unit> = runCatching {
        val ref = db.reference.child("reports").push()
        ref.setValue(
            mapOf(
                "type" to type,
                "url" to url.take(480),
                "note" to note.take(280),
                "ts" to ServerValue.TIMESTAMP,
            ),
        ).await()
        Unit
    }
}
