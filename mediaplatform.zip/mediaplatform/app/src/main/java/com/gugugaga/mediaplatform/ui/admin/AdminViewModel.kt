package com.gugugaga.mediaplatform.ui.admin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.admin.AdblockCfg
import com.gugugaga.mediaplatform.data.admin.AdminCategory
import com.gugugaga.mediaplatform.data.admin.AdminLogEntry
import com.gugugaga.mediaplatform.data.admin.AdminReport
import com.gugugaga.mediaplatform.data.admin.AdminRepository
import com.gugugaga.mediaplatform.data.admin.AdminSite
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class AdminViewModel @Inject constructor(private val repo: AdminRepository) : ViewModel() {
    val loggedIn = MutableStateFlow(repo.isLoggedIn() && !repo.timedOut())
    val busy = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)
    val lockMs = MutableStateFlow(repo.lockRemainingMs())

    val sites = MutableStateFlow<List<AdminSite>>(emptyList())
    val cats = MutableStateFlow<List<AdminCategory>>(emptyList())
    val adblock = MutableStateFlow(AdblockCfg())
    val announcement = MutableStateFlow("")
    val reports = MutableStateFlow<List<AdminReport>>(emptyList())
    val log = MutableStateFlow<List<AdminLogEntry>>(emptyList())

    init { if (!loggedIn.value) repo.logout() }

    private fun op(block: suspend () -> Unit) {
        viewModelScope.launch {
            busy.value = true
            try { block() } catch (e: Throwable) { message.value = e.message ?: "Error" } finally { busy.value = false }
        }
    }

    fun tick() {
        lockMs.value = repo.lockRemainingMs()
        if (loggedIn.value && repo.timedOut()) {
            repo.logout()
            loggedIn.value = false
            message.value = "Session expire (15 min inactivity)"
        }
    }

    fun login(code: String) = op {
        repo.login(code).fold(
            onSuccess = { loggedIn.value = true },
            onFailure = { message.value = it.message },
        )
        lockMs.value = repo.lockRemainingMs()
    }

    fun logout() { repo.logout(); loggedIn.value = false }

    fun load(tab: Int) = op {
        when (tab) {
            0 -> { sites.value = repo.sites(); reports.value = repo.reports() }
            1 -> { sites.value = repo.sites(); cats.value = repo.categories() }
            2 -> { cats.value = repo.categories() }
            3 -> { adblock.value = repo.adblock() }
            4 -> { announcement.value = repo.announcement() }
            5 -> { reports.value = repo.reports() }
            else -> { log.value = repo.log() }
        }
    }

    fun saveSite(s: AdminSite) = op { repo.saveSite(s); sites.value = repo.sites(); message.value = "Save ho gaya" }
    fun deleteSite(s: AdminSite) = op { repo.deleteSite(s); sites.value = repo.sites() }
    fun addCategory(n: String, o: Int) = op { repo.addCategory(n, o); cats.value = repo.categories() }
    fun deleteCategory(c: AdminCategory) = op { repo.deleteCategory(c); cats.value = repo.categories() }
    fun saveAdblock(c: AdblockCfg) = op { repo.saveAdblock(c); adblock.value = repo.adblock(); message.value = "Save ho gaya" }
    fun saveCosmetic(h: String, s: String) = op { repo.saveCosmetic(h, s); adblock.value = repo.adblock() }
    fun deleteCosmetic(k: String) = op { repo.deleteCosmetic(k); adblock.value = repo.adblock() }
    fun saveAnnouncement(t: String) = op { repo.saveAnnouncement(t); message.value = "Save ho gaya" }
    fun deleteReport(id: String) = op { repo.deleteReport(id); reports.value = repo.reports() }
    fun bulk(ids: List<String>, action: String, value: String = "") =
        op { repo.bulk(ids, action, value); sites.value = repo.sites(); message.value = "Done" }

    /** Move selected sites above all others (top) or below all (bottom). */
    fun moveRank(ids: List<String>, top: Boolean) = op {
        val all = repo.sites()
        val others = all.filter { it.id !in ids }
        val ranks = HashMap<String, Int>()
        if (top) {
            val base = (others.minOfOrNull { it.rankOrder } ?: 0) - ids.size
            ids.forEachIndexed { i, id -> ranks[id] = base + i }
        } else {
            val base = (others.maxOfOrNull { it.rankOrder } ?: 0) + 1
            ids.forEachIndexed { i, id -> ranks[id] = base + i }
        }
        repo.setRanks(ranks)
        sites.value = repo.sites()
        message.value = "Rank badal gaya"
    }

    fun exportSites(onText: (String) -> Unit) = op { onText(repo.exportSites()) }
    fun importSites(text: String) = op { val n = repo.importSites(text); sites.value = repo.sites(); message.value = "$n sites import hui" }

    fun clearMessage() { message.value = null }

    override fun onCleared() {
        repo.logout() // session never outlives the panel
    }
}
