package com.gugugaga.mediaplatform.browser

import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.os.Bundle
import android.webkit.WebView
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.atomic.AtomicInteger

/** One browser tab. UI-facing fields are Compose state; webView is null while suspended. */
class Tab(
    val id: Long,
    initialUrl: String,
    initialTitle: String,
    val incognito: Boolean,
    val siteId: String,
) {
    var url by mutableStateOf(initialUrl)
    var title by mutableStateOf(initialTitle)
    var progress by mutableIntStateOf(0)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var pinned by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var forceDark by mutableStateOf(false)
    var textZoom by mutableIntStateOf(100)
    var adMode by mutableStateOf("normal")
    var blocked by mutableIntStateOf(0)
    var findCount by mutableIntStateOf(0)
    var findIndex by mutableIntStateOf(0)
    var thumbnail by mutableStateOf<Bitmap?>(null)
    var webView by mutableStateOf<WebView?>(null)

    @Volatile var pageHost: String = ""
    val blockedCounter = AtomicInteger()
    var savedState: Bundle? = null
    var lastUsed: Long = System.currentTimeMillis()
    var ctxWrapper: MutableContextWrapper? = null
    var lastSavedUrl: String = ""
    var lastSavedAt: Long = 0L
}
