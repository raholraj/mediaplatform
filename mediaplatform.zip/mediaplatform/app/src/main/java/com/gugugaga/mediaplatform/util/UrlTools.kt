package com.gugugaga.mediaplatform.util

import android.net.Uri

object UrlTools {
    private val exact = setOf(
        "fbclid", "gclid", "gclsrc", "dclid", "msclkid", "mc_eid", "mc_cid", "igshid",
        "yclid", "twclid", "ttclid", "wbraid", "gbraid", "_hsenc", "_hsmi", "mkt_tok",
    )

    /** Removes utm_* / click-id tracking params. Returns the same string when nothing was removed. */
    fun stripTracking(url: String): String = runCatching {
        val u = Uri.parse(url)
        if (!u.isHierarchical) return url
        val names = u.queryParameterNames
        val drop = names.filter { it.startsWith("utm_", true) || it.lowercase() in exact }
        if (drop.isEmpty()) return url
        val b = u.buildUpon().clearQuery()
        names.filter { it !in drop }.forEach { n -> u.getQueryParameters(n).forEach { v -> b.appendQueryParameter(n, v) } }
        b.build().toString()
    }.getOrDefault(url)
}
