package com.gugugaga.mediaplatform.adblock

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.gugugaga.mediaplatform.data.AppPrefs
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

@EntryPoint
@InstallIn(SingletonComponent::class)
interface AdBlockEntry {
    fun engine(): AdBlockEngine
    fun prefs(): AppPrefs
    fun firebase(): FirebaseDatabase
}

/**
 * Daily: pulls small rules from RTDB `adblock/*` (killSwitch, extraBlockedDomains, allowlist,
 * cosmeticRules, siteModes, listUrl) and the big filter list from `listUrl` (ETag aware).
 * The big list never lives in RTDB.
 */
class AdBlockUpdateWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val e = EntryPointAccessors.fromApplication(applicationContext, AdBlockEntry::class.java)
        val prefs = e.prefs()
        try {
            val snap = withTimeout(20_000) { e.firebase().reference.child("adblock").get().await() }
            prefs.adblockKill = snap.child("killSwitch").value as? Boolean ?: false
            writeRemote(snap)
            val listUrl = snap.child("listUrl").value?.toString().orEmpty()
            if (listUrl.startsWith("https://")) downloadList(listUrl, prefs)
            e.engine().reload()
            prefs.adblockUpdatedAt = System.currentTimeMillis()
            Result.success()
        } catch (t: Throwable) {
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }

    private fun writeRemote(snap: DataSnapshot) {
        fun strings(s: DataSnapshot): JSONArray {
            val a = JSONArray()
            when (val v = s.value) {
                is String -> v.split(',', '\n').map { it.trim() }.filter { it.isNotEmpty() }.forEach { a.put(it) }
                is List<*> -> v.filterNotNull().forEach { a.put(it.toString()) }
                else -> {}
            }
            return a
        }
        val o = JSONObject()
        o.put("extra", strings(snap.child("extraBlockedDomains")))
        o.put("allow", strings(snap.child("allowlist")))
        val cos = JSONObject()
        snap.child("cosmeticRules").children.forEach { c -> c.key?.let { k -> cos.put(k, c.value?.toString().orEmpty()) } }
        o.put("cosmetic", cos)
        val modes = JSONObject()
        snap.child("siteModes").children.forEach { c -> c.key?.let { k -> modes.put(k, c.value?.toString().orEmpty()) } }
        o.put("modes", modes)
        File(applicationContext.filesDir, "adblock_remote.json").writeText(o.toString())
    }

    private fun downloadList(url: String, prefs: AppPrefs) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 30_000
            if (prefs.adblockEtag.isNotEmpty()) conn.setRequestProperty("If-None-Match", prefs.adblockEtag)
            when (conn.responseCode) {
                304 -> return
                200 -> {
                    val tmp = File(applicationContext.cacheDir, "adblock_hosts.tmp")
                    var bytes = 0L
                    conn.inputStream.use { input -> tmp.outputStream().use { out ->
                        val buf = ByteArray(16_384)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            bytes += n
                            if (bytes > 8_000_000) throw IllegalStateException("list too large")
                            out.write(buf, 0, n)
                        }
                    } }
                    // sanity check: a broken/empty list must never replace a working one
                    val lines = tmp.bufferedReader().useLines { ls -> ls.count { AdBlockEngine.parseLine(it) != null } }
                    if (lines < 100) { tmp.delete(); return }
                    val cur = File(applicationContext.filesDir, "adblock_hosts.txt")
                    if (cur.exists()) cur.copyTo(File(applicationContext.filesDir, "adblock_hosts.prev.txt"), overwrite = true)
                    tmp.copyTo(cur, overwrite = true)
                    tmp.delete()
                    conn.getHeaderField("ETag")?.let { prefs.adblockEtag = it }
                }
            }
        } finally {
            conn.disconnect()
        }
    }
}
