package com.gugugaga.mediaplatform.ui.viewer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gugugaga.mediaplatform.data.local.BookmarkDao
import com.gugugaga.mediaplatform.data.local.BookmarkEntity
import com.gugugaga.mediaplatform.data.local.CartDao
import com.gugugaga.mediaplatform.data.local.CartItem
import com.gugugaga.mediaplatform.data.remote.ReportRepository
import com.gugugaga.mediaplatform.util.Util
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ViewerViewModel @Inject constructor(
    private val cart: CartDao,
    private val bookmarks: BookmarkDao,
    private val reports: ReportRepository,
) : ViewModel() {

    fun isBookmarked(url: String): Flow<Boolean> = bookmarks.countByUrl(url).map { it > 0 }

    fun toggleBookmark(title: String, url: String, isBookmarked: Boolean) {
        viewModelScope.launch {
            if (isBookmarked) bookmarks.deleteByUrl(url)
            else bookmarks.insert(BookmarkEntity(title = title.ifBlank { Util.hostOf(url) }, url = url))
        }
    }

    fun addToCart(title: String, url: String) {
        viewModelScope.launch { cart.insert(CartItem(title = title.ifBlank { Util.hostOf(url) }, url = url)) }
    }

    fun addOfflineCart(title: String, url: String, path: String) {
        viewModelScope.launch { cart.insert(CartItem(title = title.ifBlank { Util.hostOf(url) }, url = url, offlinePath = path)) }
    }

    fun report(type: String, url: String, note: String, onDone: (Boolean) -> Unit) {
        viewModelScope.launch { onDone(reports.report(type, url, note).isSuccess) }
    }
}
