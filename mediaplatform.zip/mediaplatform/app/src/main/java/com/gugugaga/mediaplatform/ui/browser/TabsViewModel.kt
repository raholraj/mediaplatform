package com.gugugaga.mediaplatform.ui.browser

import androidx.lifecycle.ViewModel
import com.gugugaga.mediaplatform.browser.TabManager
import com.gugugaga.mediaplatform.data.AppPrefs
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class TabsViewModel @Inject constructor(val manager: TabManager, val prefs: AppPrefs) : ViewModel()
