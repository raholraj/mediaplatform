package com.gugugaga.mediaplatform.adblock

import android.content.Context
import android.net.Uri
import android.webkit.WebResourceResponse
import com.gugugaga.mediaplatform.data.AppPrefs
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Network blocking = HashSet + suffix lookup (O(labels), no regex, no main-thread work).
 * Lists are loaded on a background thread; until ready nothing is blocked (fail-open).
 */
@Singleton
class AdBlockEngine @Inject constructor(
    @ApplicationContext private val ctx: Context,
    private val prefs: AppPrefs,
) {
    @Volatile private var hosts: Set<String> = emptySet()
    @Volatile private var allow: Set<String> = DEFAULT_ALLOW
    @Volatile private var cosmetic: Map<String, String> = emptyMap()
    @Volatile private var remoteModes: Map<String, String> = emptyMap()
    @Volatile var ready: Boolean = false
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    init { scope.launch { reload() } }

    fun reloadAsync() { scope.launch { reload() } }

    fun hostCount(): Int = hosts.size

    fun reload() {
        runCatching {
            val set = HashSet<String>(4096)
            runCatching {
                ctx.assets.open("adblock_hosts.txt").bufferedReader().useLines { ls -> ls.forEach { parseLine(it)?.let(set::add) } }
            }
            val dl = File(ctx.filesDir, "adblock_hosts.txt")
            if (dl.exists()) runCatching { dl.bufferedReader().useLines { ls -> ls.forEach { parseLine(it)?.let(set::add) } } }

            val allowSet = HashSet<String>(DEFAULT_ALLOW)
            var cos: Map<String, String> = emptyMap()
            var modes: Map<String, String> = emptyMap()
            val rf = File(ctx.filesDir, "adblock_remote.json")
            if (rf.exists()) runCatching {
                val o = JSONObject(rf.readText())
                o.optJSONArray("extra")?.let { a -> for (i in 0 until a.length()) parseLine(a.optString(i))?.let(set::add) }
                o.optJSONArray("allow")?.let { a -> for (i in 0 until a.length()) a.optString(i).lowercase().takeIf { it.isNotBlank() }?.let(allowSet::add) }
                o.optJSONObject("cosmetic")?.let { c -> cos = c.keys().asSequence().associate { k -> k.replace('_', '.').lowercase() to c.optString(k) } }
                o.optJSONObject("modes")?.let { m -> modes = m.keys().asSequence().associate { k -> k.replace('_', '.').lowercase() to m.optString(k) } }
            }
            hosts = set
            allow = allowSet
            cosmetic = cos
            remoteModes = modes
            ready = true
        }
    }

    /** Effective mode for a host: kill-switch > per-site user choice > remote per-site > global. */
    fun modeFor(host: String): String {
        if (prefs.adblockKill) return "off"
        prefs.siteSetting(host, "ads")?.let { return it }
        lookupSuffix(remoteModes, host)?.let { return it }
        return prefs.adblockMode
    }

    fun shouldBlock(uri: Uri, pageHost: String?, mode: String): Boolean {
        if (!ready || mode == "off" || prefs.adblockKill) return false
        val host = uri.host?.lowercase() ?: return false
        if (matchesSuffix(allow, host)) return false
        val page = pageHost.orEmpty()
        if (page.isNotEmpty() && registrable(host) == registrable(page)) return false // first-party
        if (matchesSuffix(hosts, host)) return true
        if (mode == "strict") {
            val s = uri.toString().lowercase()
            if (STRICT_PATHS.any { s.contains(it) }) return true
        }
        return false
    }

    fun emptyResponse(uri: Uri): WebResourceResponse {
        val path = uri.lastPathSegment?.lowercase().orEmpty()
        val (mime, body) = when {
            path.endsWith(".js") -> "application/javascript" to ByteArray(0)
            path.endsWith(".css") -> "text/css" to ByteArray(0)
            path.endsWith(".png") || path.endsWith(".jpg") || path.endsWith(".jpeg") ||
                path.endsWith(".gif") || path.endsWith(".webp") || path.endsWith(".svg") -> "image/gif" to PIXEL
            else -> "text/plain" to ByteArray(0)
        }
        return WebResourceResponse(mime, "utf-8", 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), ByteArrayInputStream(body))
    }

    /** Runs at document start. Conservative selectors only (over-blocking breaks sites). */
    fun documentStartScript(): String = SCRIPT.replace("<GENERIC>", GENERIC_CSS).replace("<STRICT>", STRICT_CSS)

    /** Site specific selectors from admin (RTDB adblock/cosmeticRules/{host_with_underscores}). */
    fun cosmeticJs(host: String, mode: String): String {
        if (mode == "off") return ""
        val css = lookupSuffix(cosmetic, host)?.takeIf { it.isNotBlank() } ?: return ""
        val lit = JSONObject.quote("$css{display:none!important;}")
        return "(function(){try{var s=document.createElement('style');s.textContent=$lit;(document.head||document.documentElement).appendChild(s);}catch(e){}})();"
    }

    private fun <T> lookupSuffix(map: Map<String, T>, host: String): T? {
        var h = host.lowercase()
        while (true) {
            map[h]?.let { return it }
            val i = h.indexOf('.')
            if (i < 0) return null
            h = h.substring(i + 1)
        }
    }

    private fun matchesSuffix(set: Set<String>, host: String): Boolean {
        var h = host
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    private fun registrable(host: String): String {
        val l = host.lowercase().split('.')
        if (l.size <= 2) return host.lowercase()
        val second = l[l.size - 2]
        return if (l.last().length == 2 && second in SLD) l.takeLast(3).joinToString(".") else l.takeLast(2).joinToString(".")
    }

    companion object {
        private val SLD = setOf("co", "com", "org", "net", "gov", "ac", "edu")
        private val PIXEL = android.util.Base64.decode("R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7", android.util.Base64.DEFAULT)

        val DEFAULT_ALLOW = setOf(
            "accounts.google.com", "appleid.apple.com", "login.microsoftonline.com", "login.live.com",
            "facebook.com", "recaptcha.net", "hcaptcha.com", "challenges.cloudflare.com",
            "razorpay.com", "paytm.com", "paytmpayments.com", "stripe.com", "paypal.com", "paypalobjects.com",
        )

        private val STRICT_PATHS = listOf("/ads/", "/adserver", "/adframe", "/pagead/", "/popunder", "/doubleclick/")

        private const val GENERIC_CSS =
            ".adsbygoogle,ins.adsbygoogle,[id^=\"google_ads\"],[id*=\"div-gpt-ad\"],.ad-banner,.ad-container," +
                ".advert,.advertisement,[class*=\"adsbox\"],iframe[src*=\"doubleclick.net\"],iframe[src*=\"googlesyndication\"]," +
                "a[href*=\"doubleclick.net\"],.sponsored-ad"
        private const val STRICT_CSS =
            "iframe[src*=\"/ads/\"],iframe[src*=\"adserver\"],[class*=\"sponsored\"],.popup-ad,.ad-popup,.modal-ad"

        private val SCRIPT = """
(function(){
 if(window.__mpInit) return; window.__mpInit=1;
 var mode='normal'; try{ mode=MPAds.mode(); }catch(e){}
 if(mode==='off') return;
 var sel='<GENERIC>';
 if(mode==='strict') sel+=',<STRICT>';
 try{ var u=MPAds.rules(); if(u) sel+=','+u.split('|||').join(','); }catch(e){}
 function addCss(){ try{ var s=document.createElement('style'); s.textContent=sel+'{display:none!important;}'; (document.head||document.documentElement).appendChild(s);}catch(e){} }
 if(document.documentElement) addCss(); else document.addEventListener('DOMContentLoaded',addCss);
 var g=0; ['touchstart','pointerdown','click','keydown'].forEach(function(ev){ window.addEventListener(ev,function(){g=Date.now();},true); });
 var oo=window.open;
 window.open=function(){ if(Date.now()-g<1000){ return oo.apply(window,arguments);} return null; };
 try{ if(window.Notification){ Notification.requestPermission=function(cb){ if(cb){try{cb('denied');}catch(e){}} return Promise.resolve('denied'); }; } }catch(e){}
})();
""".trimIndent()

        /** Accepts plain domains, hosts-file lines and ||domain^ (ABP) lines. Returns null for anything else. */
        fun parseLine(raw: String): String? {
            var l = raw.trim()
            if (l.isEmpty() || l.startsWith("#") || l.startsWith("!") || l.startsWith("[")) return null
            if (l.startsWith("||")) {
                l = l.removePrefix("||")
                val end = l.indexOfFirst { it == '^' || it == '$' || it == '/' }
                if (end >= 0) {
                    if (l[end] == '/') return null
                    l = l.substring(0, end)
                }
            } else {
                val parts = l.split(Regex("\\s+"))
                l = when {
                    parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1") -> parts[1]
                    parts.size == 1 -> parts[0]
                    else -> return null
                }
            }
            l = l.lowercase().trim('.')
            if (!l.contains('.') || l.contains('*') || l.contains('/') || l.contains(':')) return null
            if (l == "localhost" || l.endsWith(".local")) return null
            return l
        }
    }
}
