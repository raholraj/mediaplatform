package com.gugugaga.mediaplatform.ui.search

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.gugugaga.mediaplatform.data.local.SiteEntity
import com.gugugaga.mediaplatform.util.Util
import com.gugugaga.mediaplatform.util.openCustomTab

@Composable
fun SearchScreen(
    onOpen: (url: String, title: String, siteId: String) -> Unit,
    vm: SearchViewModel = hiltViewModel(),
) {
    val ctx = LocalContext.current
    val q by vm.query.collectAsStateWithLifecycle()
    val res by vm.results.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    val cat by vm.catFilter.collectAsStateWithLifecycle()
    val hot by vm.hotOnly.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    val open: (String, String, String) -> Unit = { u, t, id -> vm.remember(q); onOpen(u, t, id) }
    val openSite: (SiteEntity) -> Unit = { s ->
        if (s.browsingMode.equals("customtab", true)) { vm.remember(q); Util.openCustomTab(ctx, s.url) }
        else open(s.url, s.name, s.id)
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = vm::setQuery,
            modifier = Modifier.fillMaxWidth().padding(12.dp).focusRequester(focus),
            singleLine = true,
            placeholder = { Text("Websites, cart, history search ya URL") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            trailingIcon = { if (q.isNotEmpty()) IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Filled.Close, "Clear") } },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                val t = q.trim()
                if (t.isNotEmpty()) open(Util.smartUrl(t) ?: Util.searchUrl(t), t, "")
            }),
        )

        if (q.isNotBlank()) {
            LazyRow(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(selected = hot, onClick = vm::toggleHot, label = { Text("Only Hot") }) }
                items(res.categories) { c ->
                    FilterChip(selected = cat == c, onClick = { vm.setCategory(if (cat == c) null else c) }, label = { Text(c) })
                }
            }
        }

        LazyColumn(Modifier.fillMaxSize()) {
            if (q.isBlank()) {
                val trending = vm.trending()
                if (trending.isNotEmpty()) {
                    item { Header("Trending") }
                    items(trending) { t -> ListItem(headlineContent = { Text(t) }, modifier = Modifier.clickable { vm.setQuery(t) }) }
                }
                if (recent.isNotEmpty()) {
                    item {
                        Row(Modifier.padding(horizontal = 16.dp)) {
                            Text("Recent searches", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                            TextButton(onClick = vm::clearRecent) { Text("Clear") }
                        }
                    }
                    items(recent) { r -> ListItem(headlineContent = { Text(r) }, modifier = Modifier.clickable { vm.setQuery(r) }) }
                }
                if (trending.isEmpty() && recent.isEmpty()) {
                    item {
                        Text(
                            "Search ye cheezein dhundta hai: admin ki sites (naam/tags/description), aapke dekhe hue pages ka text (sirf is phone par), cart, tabs, bookmarks, history.",
                            Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            } else {
                res.directUrl?.let { u ->
                    item { Row1("Open: $u", "App ke andar kholo", Util.faviconUrl(u)) { open(u, Util.hostOf(u), "") } }
                }
                item { Row1("Web search: ${q.trim()}", "Google (app ke andar)", null) { open(Util.searchUrl(q.trim()), q.trim(), "") } }

                if (res.sites.isNotEmpty()) {
                    item { Header("Websites") }
                    items(res.sites, key = { "s" + it.id }) { s ->
                        Row1(s.name, s.description.ifBlank { Util.hostOf(s.url) }, s.iconUrl.ifBlank { Util.faviconUrl(s.url) }) { openSite(s) }
                    }
                }
                if (res.siteSearches.isNotEmpty()) {
                    item { Header("Site ke andar search") }
                    items(res.siteSearches, key = { "ss" + it.first.id }) { (s, url) ->
                        Row1("'${res.query}' on ${s.name}", if (s.searchUrlPattern.isBlank()) "Google site: search" else "Site ka apna search", Util.faviconUrl(s.url)) {
                            open(url, s.name, "")
                        }
                    }
                }
                if (res.learned.isNotEmpty()) {
                    item { Header("Aapke dekhe hue pages") }
                    items(res.learned, key = { "l" + it.url }) { p ->
                        Row1(p.title.ifBlank { Util.hostOf(p.url) }, p.url, Util.faviconUrl(p.url)) { open(p.url, p.title, "") }
                    }
                }
                if (res.cart.isNotEmpty()) {
                    item { Header("Cart") }
                    items(res.cart, key = { "c" + it.id }) { c -> Row1(c.title, c.url, Util.faviconUrl(c.url)) { open(c.url, c.title, "") } }
                }
                if (res.tabs.isNotEmpty()) {
                    item { Header("My Tabs") }
                    items(res.tabs, key = { "t" + it.id }) { t -> Row1(t.name, t.url, Util.faviconUrl(t.url)) { open(t.url, t.name, "") } }
                }
                if (res.bookmarks.isNotEmpty()) {
                    item { Header("Bookmarks") }
                    items(res.bookmarks, key = { "b" + it.id }) { b -> Row1(b.title, b.url, Util.faviconUrl(b.url)) { open(b.url, b.title, "") } }
                }
                if (res.history.isNotEmpty()) {
                    item { Header("History") }
                    items(res.history, key = { "h" + it.id }) { h -> Row1(h.title, h.url, Util.faviconUrl(h.url)) { open(h.url, h.title, "") } }
                }
                if (res.isEmpty && res.directUrl == null) {
                    item { Text("Kuch nahi mila. Upar 'Web search' try karo.", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        }
    }
}

@Composable
private fun Header(t: String) {
    Text(t, style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 2.dp))
}

@Composable
private fun Row1(title: String, sub: String, icon: String?, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(sub, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        leadingContent = {
            if (icon != null) AsyncImage(model = icon, contentDescription = null, modifier = Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)))
            else Icon(Icons.Filled.Search, null)
        },
        modifier = Modifier.clickable(onClick = onClick),
    )
}
